# Python Programmier-Tutorial

## Inhaltsverzeichnis
1. [Einführung](#einführung)
2. [Grundlegende Konzepte](#grundlegende-konzepte)
3. [Datentypen](#datentypen)
4. [Kontrollstrukturen](#kontrollstrukturen)
5. [Funktionen](#funktionen)
6. [Objektorientierte Programmierung](#objektorientierte-programmierung)
7. [Module und Pakete](#module-und-pakete)
8. [Dateiverwaltung](#dateiverwaltung)
9. [Fehlerbehandlung](#fehlerbehandlung)
10. [Fortgeschrittene Themen](#fortgeschrittene-themen)
11. [Moderne Python-Funktionen](#moderne-python-funktionen)
12. [Beste Praktiken und Entwurfsmuster](#beste-praktiken-und-entwurfsmuster)
13. [Beispielprojekte](#beispielprojekte)

## Einführung
Python ist eine interpretierte Hochsprache, die für ihre Einfachheit und Lesbarkeit bekannt ist. Dieses Tutorial führt Sie durch alle wesentlichen Konzepte der Python-Programmierung.

### Python einrichten
1. Python von [python.org](https://python.org) herunterladen
2. Python mit aktivierter PATH-Option installieren
3. Installation überprüfen: `python --version`

## Grundlegende Konzepte

### Variablen und Zuweisungen
```python
name = "John"      # String (Zeichenkette)
alter = 25        # Integer (Ganzzahl)
groesse = 1.75    # Float (Fließkommazahl)
ist_student = True # Boolean (Wahrheitswert)
```

### Grundlegende Operationen
```python
# Arithmetische Operationen
summe = 10 + 5
differenz = 10 - 5
produkt = 10 * 5
quotient = 10 / 5
potenz = 2 ** 3
rest = 10 % 3

# String-Operationen
vorname = "John"
nachname = "Doe"
vollname = vorname + " " + nachname
```

## Datentypen

### Zahlen
```python
# Ganzzahl
x = 5
# Fließkommazahl
y = 3.14
# Komplexe Zahl
z = 2 + 3j
```

### Zeichenketten (Strings)
```python
# String-Erstellung
text = "Hallo, Welt!"
mehrzeilig = """Dies ist ein
mehrzeiliger String"""

# String-Methoden
grossbuchstaben = text.upper()
kleinbuchstaben = text.lower()
laenge = len(text)
```

### Listen
```python
# Listen-Erstellung
fruechte = ["Apfel", "Banane", "Orange"]

# Listen-Operationen
fruechte.append("Weintraube")
fruechte.remove("Banane")
erste_frucht = fruechte[0]
```

### Wörterbücher (Dictionaries)
```python
# Dictionary-Erstellung
person = {
    "name": "John",
    "alter": 25,
    "stadt": "Berlin"
}

# Dictionary-Operationen
person["email"] = "john@beispiel.de"
alter = person.get("alter")
```

## Kontrollstrukturen

### If-Anweisungen
```python
alter = 18

if alter >= 18:
    print("Erwachsener")
elif alter >= 13:
    print("Teenager")
else:
    print("Kind")
```

### Schleifen
```python
# For-Schleife
for i in range(5):
    print(i)

# While-Schleife
zaehler = 0
while zaehler < 5:
    print(zaehler)
    zaehler += 1
```

## Funktionen

### Einfache Funktionen
```python
def begruessen(name):
    return f"Hallo, {name}!"

# Funktionsaufruf
nachricht = begruessen("John")
```

### Lambda-Funktionen
```python
quadrat = lambda x: x ** 2
ergebnis = quadrat(5)  # Gibt 25 zurück
```

## Objektorientierte Programmierung

### Klassen und Objekte
```python
class Person:
    def __init__(self, name, alter):
        self.name = name
        self.alter = alter
    
    def vorstellen(self):
        return f"Ich bin {self.name}, {self.alter} Jahre alt"

# Objekt erstellen
person = Person("John", 25)
vorstellung = person.vorstellen()
```

### Vererbung
```python
class Student(Person):
    def __init__(self, name, alter, matrikelnummer):
        super().__init__(name, alter)
        self.matrikelnummer = matrikelnummer
    
    def lernen(self):
        return f"{self.name} lernt gerade"
```

## Module und Pakete

### Eingebaute Module verwenden
```python
import math
import random

# Mathematische Operationen
wurzel = math.sqrt(16)
zufallszahl = random.randint(1, 10)
```

### Eigene Module erstellen
```python
# meinmodul.py
def eigene_funktion():
    return "Hallo aus eigenem Modul!"

# main.py
import meinmodul
ergebnis = meinmodul.eigene_funktion()
```

## Dateiverwaltung

### Dateien lesen und schreiben
```python
# In Datei schreiben
with open("beispiel.txt", "w") as datei:
    datei.write("Hallo, Welt!")

# Aus Datei lesen
with open("beispiel.txt", "r") as datei:
    inhalt = datei.read()
```

## Fehlerbehandlung

### Try-Except-Blöcke
```python
try:
    ergebnis = 10 / 0
except ZeroDivisionError:
    print("Division durch Null nicht möglich!")
except Exception as e:
    print(f"Ein Fehler ist aufgetreten: {e}")
finally:
    print("Dies wird immer ausgeführt")
```

## Fortgeschrittene Themen

### Typ-Hinweise und Statische Typ-Überprüfung
```python
from typing import List, Dict, Optional, Union, Callable

# Funktion mit Typ-Hinweisen
def berechne_statistiken(zahlen: List[float]) -> Dict[str, float]:
    return {
        "mittelwert": sum(zahlen) / len(zahlen),
        "maximum": max(zahlen),
        "minimum": min(zahlen)
    }

# Komplexe Typ-Hinweise
BenutzerID = int
Benutzername = str
BenutzerDaten = Dict[BenutzerID, Benutzername]

def verarbeite_benutzer(benutzer_id: BenutzerID, name: Optional[str] = None) -> None:
    pass

# Typ-Aliase und Vereinigungen
Zahl = Union[int, float]
def quadriere_zahl(n: Zahl) -> Zahl:
    return n * n
```

### Kontext-Manager
```python
from contextlib import contextmanager
import time

# Benutzerdefinierter Kontext-Manager
class Zeitmesser:
    def __enter__(self):
        self.start = time.time()
        return self
    
    def __exit__(self, *args):
        self.ende = time.time()
        self.dauer = self.ende - self.start

# Kontext-Manager mit Dekorator
@contextmanager
def temporaere_datei(dateiname: str):
    try:
        f = open(dateiname, 'w')
        yield f
    finally:
        f.close()
        import os
        os.remove(dateiname)

# Verwendung
with Zeitmesser() as timer:
    time.sleep(1)
print(f"Operation dauerte {timer.dauer:.2f} Sekunden")
```

### Asynchrone Programmierung
```python
import asyncio
from aiohttp import ClientSession

async def hole_daten(url: str) -> dict:
    async with ClientSession() as session:
        async with session.get(url) as response:
            return await response.json()

async def verarbeite_urls(urls: List[str]) -> List[dict]:
    tasks = [hole_daten(url) for url in urls]
    return await asyncio.gather(*tasks)

# Event-Loop Verwendung
async def main():
    urls = [
        "https://api.beispiel.de/daten1",
        "https://api.beispiel.de/daten2"
    ]
    ergebnisse = await verarbeite_urls(urls)
    return ergebnisse

if __name__ == "__main__":
    asyncio.run(main())
```

### Dekoratoren und Metaprogrammierung
```python
from functools import wraps
import time
import logging

# Funktions-Dekorator
def zeitmessung_dekorator(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.time()
        ergebnis = func(*args, **kwargs)
        ende = time.time()
        print(f"{func.__name__} benötigte {ende - start:.2f} Sekunden")
        return ergebnis
    return wrapper

# Klassen-Dekorator
def singleton(cls):
    instanzen = {}
    def hole_instanz(*args, **kwargs):
        if cls not in instanzen:
            instanzen[cls] = cls(*args, **kwargs)
        return instanzen[cls]
    return hole_instanz

# Dekorator mit Parametern
def wiederhole(max_versuche: int = 3, verzoegerung: float = 1.0):
    def dekorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            versuche = 0
            while versuche < max_versuche:
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    versuche += 1
                    if versuche == max_versuche:
                        raise e
                    time.sleep(verzoegerung)
        return wrapper
    return dekorator
```

### Fortgeschrittene Datenstrukturen
```python
from collections import defaultdict, Counter, deque
from typing import TypeVar, Generic

T = TypeVar('T')

# Generischer Stack
class Stapel(Generic[T]):
    def __init__(self):
        self._elemente: List[T] = []
    
    def lege_drauf(self, element: T) -> None:
        self._elemente.append(element)
    
    def nehme_runter(self) -> T:
        return self._elemente.pop()
    
    def schaue_oben(self) -> T:
        return self._elemente[-1]
    
    def ist_leer(self) -> bool:
        return len(self._elemente) == 0

# Collections verwenden
def verarbeite_logdatei(dateiname: str) -> Dict[str, int]:
    # Zähle Vorkommen automatisch
    wort_zaehler = Counter()
    
    # Standard-Dictionary mit Liste
    benutzer_aktionen = defaultdict(list)
    
    # Doppelseitige Warteschlange
    letzte_ereignisse = deque(maxlen=100)
    
    with open(dateiname) as f:
        for zeile in f:
            # Verarbeite Logdatei...
            pass
            
    return dict(wort_zaehler)
```

### Moderne Python-Funktionen (Python 3.9+)
```python
# Dictionary Vereinigungsoperatoren (Python 3.9+)
dict1 = {"a": 1, "b": 2}
dict2 = {"c": 3, "d": 4}
kombiniert = dict1 | dict2

# Musterabgleich (Python 3.10+)
def verarbeite_befehl(befehl):
    match befehl.split():
        case ["beenden"]:
            return "Wird beendet..."
        case ["laden", dateiname]:
            return f"Lade {dateiname}"
        case ["speichern", dateiname, "als", format]:
            return f"Speichere {dateiname} als {format}"
        case _:
            return "Unbekannter Befehl"

# Typ-Vereinigungsoperator (Python 3.10+)
def verarbeite_id(id: int | str) -> str:
    return str(id)
```

### Fortgeschrittene Testtechniken
```python
import pytest
from unittest.mock import Mock, patch
from dataclasses import dataclass

@dataclass
class Benutzer:
    id: int
    name: str
    email: str

class BenutzerService:
    def __init__(self, db):
        self.db = db
    
    def hole_benutzer(self, benutzer_id: int) -> Optional[Benutzer]:
        return self.db.query(Benutzer).filter_by(id=benutzer_id).first()

# Fixtures
@pytest.fixture
def mock_db():
    return Mock()

@pytest.fixture
def benutzer_service(mock_db):
    return BenutzerService(mock_db)

# Parametrisierte Tests
@pytest.mark.parametrize("benutzer_id,erwarteter_name", [
    (1, "Hans"),
    (2, "Anna"),
    (3, None)
])
def test_hole_benutzer(benutzer_service, mock_db, benutzer_id, erwarteter_name):
    # Vorbereiten
    mock_db.query.return_value.filter_by.return_value.first.return_value = (
        Benutzer(id=benutzer_id, name=erwarteter_name, email="test@beispiel.de")
        if erwarteter_name else None
    )
    
    # Ausführen
    ergebnis = benutzer_service.hole_benutzer(benutzer_id)
    
    # Überprüfen
    if erwarteter_name:
        assert ergebnis.name == erwarteter_name
    else:
        assert ergebnis is None
```

### Leistungsoptimierung
```python
from functools import lru_cache
import cProfile
import pstats
import io

# Memoisation mit LRU Cache
@lru_cache(maxsize=128)
def fibonacci(n: int) -> int:
    if n < 2:
        return n
    return fibonacci(n-1) + fibonacci(n-2)

# Profiling-Dekorator
def profil(func):
    def wrapper(*args, **kwargs):
        pr = cProfile.Profile()
        pr.enable()
        ergebnis = func(*args, **kwargs)
        pr.disable()
        s = io.StringIO()
        ps = pstats.Stats(pr, stream=s).sort_stats('cumulative')
        ps.print_stats()
        print(s.getvalue())
        return ergebnis
    return wrapper

# Generator für Speichereffizienz
def verarbeite_grosse_datei(dateiname: str):
    with open(dateiname) as f:
        for zeile in f:
            # Verarbeite zeilenweise statt die ganze Datei zu laden
            yield zeile.strip().split(',')
```

## Beste Praktiken und Entwurfsmuster

### Clean Code Prinzipien
```python
# Schlecht
def p(x, l):
    if l == []: return x
    return p(x * l[0], l[1:])

# Gut
def berechne_produkt(anfangswert: float, faktoren: List[float]) -> float:
    """Berechne das Produkt von anfangswert und allen Faktoren in der Liste."""
    if not faktoren:
        return anfangswert
    return berechne_produkt(anfangswert * faktoren[0], faktoren[1:])

# Schlecht
class Obj:
    def mache_etwas(self, x):
        if x > 0:
            # Mache etwas
            pass
        else:
            # Mache etwas anderes
            pass

# Gut
class DatenVerarbeiter:
    def verarbeite_daten(self, wert: float) -> None:
        """Verarbeite Daten basierend auf ihrem Wert."""
        if self._ist_positiv(wert):
            self._verarbeite_positiven_wert(wert)
        else:
            self._verarbeite_negativen_wert(wert)
    
    def _ist_positiv(self, wert: float) -> bool:
        return wert > 0
```

### Entwurfsmuster
```python
# Singleton-Muster
class Singleton:
    _instanz = None
    
    def __new__(cls):
        if cls._instanz is None:
            cls._instanz = super().__new__(cls)
        return cls._instanz

# Fabrik-Muster
from abc import ABC, abstractmethod

class Tier(ABC):
    @abstractmethod
    def spreche(self) -> str:
        pass

class Hund(Tier):
    def spreche(self) -> str:
        return "Wuff!"

class Katze(Tier):
    def spreche(self) -> str:
        return "Miau!"

class TierFabrik:
    def erstelle_tier(self, tier_typ: str) -> Tier:
        if tier_typ.lower() == "hund":
            return Hund()
        elif tier_typ.lower() == "katze":
            return Katze()
        raise ValueError(f"Unbekannter Tier-Typ: {tier_typ}")

# Beobachter-Muster
class Subjekt:
    def __init__(self):
        self._beobachter = []
        self._zustand = None
    
    def registriere(self, beobachter):
        self._beobachter.append(beobachter)
    
    def entferne(self, beobachter):
        self._beobachter.remove(beobachter)
    
    def benachrichtige(self):
        for beobachter in self._beobachter:
            beobachter.aktualisiere(self._zustand)
    
    @property
    def zustand(self):
        return self._zustand
    
    @zustand.setter
    def zustand(self, wert):
        self._zustand = wert
        self.benachrichtige()
```

### Fehlerbehandlung und Protokollierung
```python
import logging
from typing import Any, Optional
from dataclasses import dataclass

# Protokollierung einrichten
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@dataclass
class OperationsErgebnis:
    erfolg: bool
    daten: Optional[Any] = None
    fehler: Optional[str] = None

class BenutzerdefinierterFehler(Exception):
    """Basisklasse für benutzerdefinierte Ausnahmen"""
    pass

def verarbeite_daten(daten: Dict[str, Any]) -> OperationsErgebnis:
    try:
        # Eingabe validieren
        if not isinstance(daten, dict):
            raise TypeError("Eingabe muss ein Dictionary sein")
        
        # Daten verarbeiten
        ergebnis = fuehre_komplexe_operation_aus(daten)
        logger.info(f"Daten erfolgreich verarbeitet: {daten}")
        
        return OperationsErgebnis(erfolg=True, daten=ergebnis)
    
    except TypeError as e:
        logger.error(f"Ungültiger Eingabetyp: {str(e)}")
        return OperationsErgebnis(erfolg=False, fehler=str(e))
    
    except BenutzerdefinierterFehler as e:
        logger.error(f"Geschäftslogik-Fehler: {str(e)}")
        return OperationsErgebnis(erfolg=False, fehler=str(e))
    
    except Exception as e:
        logger.exception("Unerwarteter Fehler aufgetreten")
        return OperationsErgebnis(erfolg=False, fehler="Interner Serverfehler")
```

## Beispielprojekte

### Web-API mit FastAPI
```python
from fastapi import FastAPI, HTTPException, Depends
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import List

app = FastAPI()

class BenutzerErstellen(BaseModel):
    name: str
    email: str

class Benutzer(BenutzerErstellen):
    id: int
    
    class Config:
        orm_mode = True

@app.post("/benutzer/", response_model=Benutzer)
async def erstelle_benutzer(benutzer: BenutzerErstellen, db: Session = Depends(hole_db)):
    db_benutzer = BenutzerModell(**benutzer.dict())
    db.add(db_benutzer)
    db.commit()
    db.refresh(db_benutzer)
    return db_benutzer

@app.get("/benutzer/", response_model=List[Benutzer])
async def hole_benutzer(ueberspringe: int = 0, limit: int = 100, db: Session = Depends(hole_db)):
    benutzer = db.query(BenutzerModell).offset(ueberspringe).limit(limit).all()
    return benutzer
```

### Datenverarbeitungs-Pipeline
```python
from dataclasses import dataclass
from typing import List, Iterator
import pandas as pd
import numpy as np

@dataclass
class Datenpunkt:
    zeitstempel: float
    wert: float
    kategorie: str

class DatenPipeline:
    def __init__(self, eingabedatei: str):
        self.eingabedatei = eingabedatei
        self.daten: List[Datenpunkt] = []
    
    def lade_daten(self) -> None:
        df = pd.read_csv(self.eingabedatei)
        self.daten = [
            Datenpunkt(zeile.zeitstempel, zeile.wert, zeile.kategorie)
            for zeile in df.itertuples()
        ]
    
    def verarbeite_daten(self) -> Iterator[Datenpunkt]:
        for punkt in self.daten:
            # Transformationen anwenden
            verarbeiteter_punkt = self._transformiere_punkt(punkt)
            if verarbeiteter_punkt:
                yield verarbeiteter_punkt
    
    def _transformiere_punkt(self, punkt: Datenpunkt) -> Optional[Datenpunkt]:
        # Geschäftslogik anwenden
        if punkt.wert < 0:
            return None
        return Datenpunkt(
            zeitstempel=punkt.zeitstempel,
            wert=np.log1p(punkt.wert),
            kategorie=punkt.kategorie.upper()
        )
```

Damit ist das umfassende Python-Tutorial mit fortgeschrittenen Funktionen, besten Praktiken und praktischen Beispielen abgeschlossen.

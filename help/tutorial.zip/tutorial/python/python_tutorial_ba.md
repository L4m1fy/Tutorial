# Python Programiranje Tutorial

## Sadržaj
1. [Uvod](#uvod)
2. [Osnovni Koncepti](#osnovni-koncepti)
3. [Tipovi Podataka](#tipovi-podataka)
4. [Kontrolne Strukture](#kontrolne-strukture)
5. [Funkcije](#funkcije)
6. [Objektno Orijentirano Programiranje](#objektno-orijentirano-programiranje)
7. [Moduli i Paketi](#moduli-i-paketi)
8. [Rad sa Datotekama](#rad-sa-datotekama)
9. [Rukovanje Greškama](#rukovanje-greskama)
10. [Napredne Teme](#napredne-teme)

## Uvod
Python je programski jezik visokog nivoa poznat po svojoj jednostavnosti i čitljivosti. Ovaj tutorial će vas voditi kroz sve osnovne koncepte Python programiranja.

### Postavljanje Pythona
1. Preuzmite Python sa [python.org](https://python.org)
2. Instalirajte Python sa omogućenom PATH opcijom
3. Provjerite instalaciju: `python --version`

## Osnovni Koncepti

### Varijable i Dodjeljivanje
```python
ime = "John"      # String (tekst)
godine = 25      # Integer (cijeli broj)
visina = 1.75    # Float (decimalni broj)
je_student = True # Boolean (logička vrijednost)
```

### Osnovne Operacije
```python
# Aritmetičke operacije
zbir = 10 + 5
razlika = 10 - 5
proizvod = 10 * 5
kolicnik = 10 / 5
stepen = 2 ** 3
ostatak = 10 % 3

# Operacije sa stringovima
ime = "John"
prezime = "Doe"
puno_ime = ime + " " + prezime
```

## Tipovi Podataka

### Brojevi
```python
# Cijeli broj
x = 5
# Decimalni broj
y = 3.14
# Kompleksni broj
z = 2 + 3j
```

### Stringovi
```python
# Kreiranje stringa
tekst = "Zdravo, Svijete!"
vise_linija = """Ovo je tekst
u više linija"""

# String metode
velika_slova = tekst.upper()
mala_slova = tekst.lower()
duzina = len(tekst)
```

### Liste
```python
# Kreiranje liste
voce = ["jabuka", "banana", "narandža"]

# Operacije sa listama
voce.append("grožđe")
voce.remove("banana")
prvo_voce = voce[0]
```

### Rječnici (Dictionaries)
```python
# Kreiranje rječnika
osoba = {
    "ime": "John",
    "godine": 25,
    "grad": "Sarajevo"
}

# Operacije sa rječnicima
osoba["email"] = "john@primjer.ba"
godine = osoba.get("godine")
```

## Kontrolne Strukture

### If Izjave
```python
godine = 18

if godine >= 18:
    print("Punoljetan")
elif godine >= 13:
    print("Tinejdžer")
else:
    print("Dijete")
```

### Petlje
```python
# For petlja
for i in range(5):
    print(i)

# While petlja
brojac = 0
while brojac < 5:
    print(brojac)
    brojac += 1
```

## Funkcije

### Osnovne Funkcije
```python
def pozdravi(ime):
    return f"Zdravo, {ime}!"

# Poziv funkcije
poruka = pozdravi("John")
```

### Lambda Funkcije
```python
kvadrat = lambda x: x ** 2
rezultat = kvadrat(5)  # Vraća 25
```

## Objektno Orijentirano Programiranje

### Klase i Objekti
```python
class Osoba:
    def __init__(self, ime, godine):
        self.ime = ime
        self.godine = godine
    
    def predstavi_se(self):
        return f"Ja sam {self.ime}, imam {self.godine} godina"

# Kreiranje objekta
osoba = Osoba("John", 25)
predstavljanje = osoba.predstavi_se()
```

### Nasljeđivanje
```python
class Student(Osoba):
    def __init__(self, ime, godine, broj_indeksa):
        super().__init__(ime, godine)
        self.broj_indeksa = broj_indeksa
    
    def uci(self):
        return f"{self.ime} uči"
```

## Moduli i Paketi

### Korištenje Ugrađenih Modula
```python
import math
import random

# Matematičke operacije
korijen = math.sqrt(16)
slucajan_broj = random.randint(1, 10)
```

### Kreiranje Vlastitih Modula
```python
# moj_modul.py
def vlastita_funkcija():
    return "Pozdrav iz vlastitog modula!"

# main.py
import moj_modul
rezultat = moj_modul.vlastita_funkcija()
```

## Rad sa Datotekama

### Čitanje i Pisanje Datoteka
```python
# Pisanje u datoteku
with open("primjer.txt", "w") as datoteka:
    datoteka.write("Zdravo, Svijete!")

# Čitanje iz datoteke
with open("primjer.txt", "r") as datoteka:
    sadrzaj = datoteka.read()
```

## Rukovanje Greškama

### Try-Except Blokovi
```python
try:
    rezultat = 10 / 0
except ZeroDivisionError:
    print("Nije moguće dijeliti sa nulom!")
except Exception as e:
    print(f"Došlo je do greške: {e}")
finally:
    print("Ovo se uvijek izvršava")
```

## Napredne Teme

### Dekoratori
```python
def moj_dekorator(func):
    def wrapper():
        print("Prije funkcije")
        func()
        print("Nakon funkcije")
    return wrapper

@moj_dekorator
def reci_zdravo():
    print("Zdravo!")
```

### Generatori
```python
def generator_brojeva(n):
    for i in range(n):
        yield i

# Korištenje generatora
gen = generator_brojeva(5)
for broj in gen:
    print(broj)
```

### Upravljanje Kontekstom
```python
class MojKontekstMenadzer:
    def __enter__(self):
        print("Ulazak u kontekst")
        return self
    
    def __exit__(self, exc_type, exc_value, traceback):
        print("Izlazak iz konteksta")

# Korištenje kontekst menadžera
with MojKontekstMenadzer():
    print("Unutar konteksta")
```

### List Comprehensions
```python
# List comprehension
kvadrati = [x**2 for x in range(10)]

# Dictionary comprehension
rjecnik_kvadrata = {x: x**2 for x in range(5)}
```

## Najbolje Prakse

1. Pratite PEP 8 stil pisanja koda
2. Koristite smislena imena varijabli
3. Pišite docstrings za funkcije i klase
4. Držite funkcije malim i fokusiranim
5. Koristite type hints za bolju čitljivost
6. Pravilno rukujte greškama
7. Pišite unit testove za svoj kod

## Dodatni Resursi

1. [Službena Python Dokumentacija](https://docs.python.org)
2. [Python Package Index (PyPI)](https://pypi.org)
3. [Python Zajednica BiH](https://pythonba.com)
4. [Python Tutorijali na Bosanskom](https://tutorijaliba.com/python)

## Projekti za Vježbu

1. Napravite jednostavan kalkulator
2. Izgradite aplikaciju za to-do listu
3. Implementirajte jednostavan web scraper
4. Napravite organizator datoteka
5. Izgradite jednostavnu igru (npr. Iks-Oks)

Ne zaboravite redovno vježbati i raditi na stvarnim projektima kako biste poboljšali svoje Python programerske vještine!

## Napredne Python Funkcije

### Tipske Anotacije i Statička Provjera Tipova
```python
from typing import List, Dict, Optional, Union, Callable

# Funkcija sa tipskim anotacijama
def izracunaj_statistiku(brojevi: List[float]) -> Dict[str, float]:
    return {
        "srednja_vrijednost": sum(brojevi) / len(brojevi),
        "maksimum": max(brojevi),
        "minimum": min(brojevi)
    }

# Složene tipske anotacije
KorisnikID = int
KorisnickoIme = str
PodaciKorisnika = Dict[KorisnikID, KorisnickoIme]

def obradi_korisnika(korisnik_id: KorisnikID, ime: Optional[str] = None) -> None:
    pass

# Tipski aliasi i unije
Broj = Union[int, float]
def kvadriraj_broj(n: Broj) -> Broj:
    return n * n
```

### Kontekst Menadžeri
```python
from contextlib import contextmanager
import time

# Prilagođeni kontekst menadžer
class MjeracVremena:
    def __enter__(self):
        self.pocetak = time.time()
        return self

    def __exit__(self, *args):
        self.kraj = time.time()
        self.trajanje = self.kraj - self.pocetak

# Kontekst menadžer korištenjem dekoratora
@contextmanager
def privremena_datoteka(ime_datoteke: str):
    try:
        f = open(ime_datoteke, 'w')
        yield f
    finally:
        f.close()
        import os
        os.remove(ime_datoteke)

# Upotreba
with MjeracVremena() as timer:
    time.sleep(1)
print(f"Operacija je trajala {timer.trajanje:.2f} sekundi")
```

### Asinhrono Programiranje
```python
import asyncio
from aiohttp import ClientSession

async def preuzmi_podatke(url: str) -> dict:
    async with ClientSession() as sesija:
        async with sesija.get(url) as odgovor:
            return await odgovor.json()

async def obradi_urlove(urlovi: List[str]) -> List[dict]:
    zadaci = [preuzmi_podatke(url) for url in urlovi]
    return await asyncio.gather(*zadaci)

# Korištenje event loop-a
async def main():
    urlovi = [
        "https://api.primjer.ba/podaci1",
        "https://api.primjer.ba/podaci2"
    ]
    rezultati = await obradi_urlove(urlovi)
    return rezultati

if __name__ == "__main__":
    asyncio.run(main())
```

### Dekoratori i Metaprogramiranje
```python
from functools import wraps
import time
import logging

# Funkcijski dekorator
def dekorator_mjerenja_vremena(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        pocetak = time.time()
        rezultat = func(*args, **kwargs)
        kraj = time.time()
        print(f"{func.__name__} je trajala {kraj - pocetak:.2f} sekundi")
        return rezultat
    return wrapper

# Klasni dekorator
def singleton(cls):
    instance = {}
    def get_instance(*args, **kwargs):
        if cls not in instance:
            instance[cls] = cls(*args, **kwargs)
        return instance[cls]
    return get_instance

# Dekorator sa parametrima
def ponovi(max_pokusaja: int = 3, pauza: float = 1.0):
    def dekorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            pokusaji = 0
            while pokusaji < max_pokusaja:
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    pokusaji += 1
                    if pokusaji == max_pokusaja:
                        raise e
                    time.sleep(pauza)
        return wrapper
    return dekorator
```

### Napredne Strukture Podataka
```python
from collections import defaultdict, Counter, deque
from typing import TypeVar, Generic

T = TypeVar('T')

# Generički Stek
class Stek(Generic[T]):
    def __init__(self):
        self._elementi: List[T] = []
    
    def dodaj(self, element: T) -> None:
        self._elementi.append(element)
    
    def ukloni(self) -> T:
        return self._elementi.pop()
    
    def pogledaj(self) -> T:
        return self._elementi[-1]
    
    def je_prazan(self) -> bool:
        return len(self._elementi) == 0

# Korištenje kolekcija
def obradi_log_datoteku(ime_datoteke: str) -> Dict[str, int]:
    # Automatsko brojanje pojavljivanja
    brojac_rijeci = Counter()
    
    # Podrazumijevani rječnik sa listom
    akcije_korisnika = defaultdict(list)
    
    # Dvostrani red
    nedavni_dogadjaji = deque(maxlen=100)
    
    with open(ime_datoteke) as f:
        for linija in f:
            # Obrada log datoteke...
            pass
            
    return dict(brojac_rijeci)
```

### Moderne Python Funkcije (Python 3.9+)
```python
# Operatori unije rječnika (Python 3.9+)
rjecnik1 = {"a": 1, "b": 2}
rjecnik2 = {"c": 3, "d": 4}
kombinovano = rjecnik1 | rjecnik2

# Podudaranje obrazaca (Python 3.10+)
def obradi_komandu(komanda):
    match komanda.split():
        case ["izadji"]:
            return "Izlazim..."
        case ["ucitaj", ime_datoteke]:
            return f"Učitavam {ime_datoteke}"
        case ["sacuvaj", ime_datoteke, "kao", format]:
            return f"Čuvam {ime_datoteke} kao {format}"
        case _:
            return "Nepoznata komanda"

# Operator unije tipova (Python 3.10+)
def obradi_id(id: int | str) -> str:
    return str(id)
```

### Napredne Tehnike Testiranja
```python
import pytest
from unittest.mock import Mock, patch
from dataclasses import dataclass

@dataclass
class Korisnik:
    id: int
    ime: str
    email: str

class KorisnikServis:
    def __init__(self, db):
        self.db = db
    
    def dohvati_korisnika(self, korisnik_id: int) -> Optional[Korisnik]:
        return self.db.query(Korisnik).filter_by(id=korisnik_id).first()

# Fixtures
@pytest.fixture
def mock_db():
    return Mock()

@pytest.fixture
def korisnik_servis(mock_db):
    return KorisnikServis(mock_db)

# Parametrizirani testovi
@pytest.mark.parametrize("korisnik_id,ocekivano_ime", [
    (1, "Adnan"),
    (2, "Amina"),
    (3, None)
])
def test_dohvati_korisnika(korisnik_servis, mock_db, korisnik_id, ocekivano_ime):
    # Priprema
    mock_db.query.return_value.filter_by.return_value.first.return_value = (
        Korisnik(id=korisnik_id, ime=ocekivano_ime, email="test@primjer.ba")
        if ocekivano_ime else None
    )
    
    # Izvršavanje
    rezultat = korisnik_servis.dohvati_korisnika(korisnik_id)
    
    # Provjera
    if ocekivano_ime:
        assert rezultat.ime == ocekivano_ime
    else:
        assert rezultat is None
```

### Optimizacija Performansi
```python
from functools import lru_cache
import cProfile
import pstats
import io

# Memoizacija sa LRU Cache
@lru_cache(maxsize=128)
def fibonacci(n: int) -> int:
    if n < 2:
        return n
    return fibonacci(n-1) + fibonacci(n-2)

# Dekorator za profiliranje
def profiliraj(func):
    def wrapper(*args, **kwargs):
        pr = cProfile.Profile()
        pr.enable()
        rezultat = func(*args, **kwargs)
        pr.disable()
        s = io.StringIO()
        ps = pstats.Stats(pr, stream=s).sort_stats('cumulative')
        ps.print_stats()
        print(s.getvalue())
        return rezultat
    return wrapper

# Generator za efikasnost memorije
def obradi_veliku_datoteku(ime_datoteke: str):
    with open(ime_datoteke) as f:
        for linija in f:
            # Obrada liniju po liniju umjesto učitavanja cijele datoteke
            yield linija.strip().split(',')
```

## Najbolje Prakse i Dizajn Obrasci

### Principi Čistog Koda
```python
# Loše
def p(x, l):
    if l == []: return x
    return p(x * l[0], l[1:])

# Dobro
def izracunaj_proizvod(pocetna_vrijednost: float, faktori: List[float]) -> float:
    """Izračunava proizvod početne vrijednosti i svih faktora u listi."""
    if not faktori:
        return pocetna_vrijednost
    return izracunaj_proizvod(pocetna_vrijednost * faktori[0], faktori[1:])

# Loše
class Obj:
    def uradi_nesto(self, x):
        if x > 0:
            # Uradi nešto
            pass
        else:
            # Uradi nešto drugo
            pass

# Dobro
class ObradaPodataka:
    def obradi_podatke(self, vrijednost: float) -> None:
        """Obrađuje podatke na osnovu njihove vrijednosti."""
        if self._je_pozitivno(vrijednost):
            self._obradi_pozitivnu_vrijednost(vrijednost)
        else:
            self._obradi_negativnu_vrijednost(vrijednost)
    
    def _je_pozitivno(self, vrijednost: float) -> bool:
        return vrijednost > 0
```

### Dizajn Obrasci
```python
# Singleton Obrazac
class Singleton:
    _instanca = None
    
    def __new__(cls):
        if cls._instanca is None:
            cls._instanca = super().__new__(cls)
        return cls._instanca

# Factory Obrazac
from abc import ABC, abstractmethod

class Zivotinja(ABC):
    @abstractmethod
    def oglasi_se(self) -> str:
        pass

class Pas(Zivotinja):
    def oglasi_se(self) -> str:
        return "Av!"

class Macka(Zivotinja):
    def oglasi_se(self) -> str:
        return "Mjau!"

class ZivotinjaFabrika:
    def kreiraj_zivotinju(self, tip_zivotinje: str) -> Zivotinja:
        if tip_zivotinje.lower() == "pas":
            return Pas()
        elif tip_zivotinje.lower() == "macka":
            return Macka()
        raise ValueError(f"Nepoznat tip životinje: {tip_zivotinje}")

# Observer Obrazac
class Subjekat:
    def __init__(self):
        self._posmatraci = []
        self._stanje = None
    
    def dodaj(self, posmatrac):
        self._posmatraci.append(posmatrac)
    
    def ukloni(self, posmatrac):
        self._posmatraci.remove(posmatrac)
    
    def obavijesti(self):
        for posmatrac in self._posmatraci:
            posmatrac.azuriraj(self._stanje)
    
    @property
    def stanje(self):
        return self._stanje
    
    @stanje.setter
    def stanje(self, vrijednost):
        self._stanje = vrijednost
        self.obavijesti()
```

### Rukovanje Greškama i Logovanje
```python
import logging
from typing import Any, Optional
from dataclasses import dataclass

@dataclass
class RezultatOperacije:
    uspjeh: bool
    podaci: Optional[Any] = None
    greska: Optional[str] = None

class PrilagodjenjaGreska(Exception):
    """Osnovna klasa za prilagođene izuzetke"""
    pass

def obradi_podatke(podaci: Dict[str, Any]) -> RezultatOperacije:
    try:
        # Validacija ulaza
        if not isinstance(podaci, dict):
            raise TypeError("Ulaz mora biti rječnik")
        
        # Obrada podataka
        rezultat = izvrsi_slozenu_operaciju(podaci)
        logging.info(f"Uspješno obrađeni podaci: {podaci}")
        
        return RezultatOperacije(uspjeh=True, podaci=rezultat)
    
    except TypeError as e:
        logging.error(f"Nevažeći tip ulaza: {str(e)}")
        return RezultatOperacije(uspjeh=False, greska=str(e))
    
    except PrilagodjenjaGreska as e:
        logging.error(f"Greška u poslovnoj logici: {str(e)}")
        return RezultatOperacije(uspjeh=False, greska=str(e))
    
    except Exception as e:
        logging.exception("Došlo je do neočekivane greške")
        return RezultatOperacije(uspjeh=False, greska="Interna greška servera")
```

## Primjer Projekata

### Web API sa FastAPI
```python
from fastapi import FastAPI, HTTPException, Depends
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import List

app = FastAPI()

class KreiranjeKorisnika(BaseModel):
    ime: str
    email: str

class Korisnik(KreiranjeKorisnika):
    id: int
    
    class Config:
        orm_mode = True

@app.post("/korisnici/", response_model=Korisnik)
async def kreiraj_korisnika(korisnik: KreiranjeKorisnika, db: Session = Depends(get_db)):
    db_korisnik = KorisnikModel(**korisnik.dict())
    db.add(db_korisnik)
    db.commit()
    db.refresh(db_korisnik)
    return db_korisnik

@app.get("/korisnici/", response_model=List[Korisnik])
async def dohvati_korisnike(preskoci: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    korisnici = db.query(KorisnikModel).offset(preskoci).limit(limit).all()
    return korisnici
```

### Protok Obrade Podataka
```python
from dataclasses import dataclass
from typing import List, Iterator
import pandas as pd
import numpy as np

@dataclass
class TackaPodataka:
    vremenska_oznaka: float
    vrijednost: float
    kategorija: str

class ProtokPodataka:
    def __init__(self, ulazna_datoteka: str):
        self.ulazna_datoteka = ulazna_datoteka
        self.podaci: List[TackaPodataka] = []
    
    def ucitaj_podatke(self) -> None:
        df = pd.read_csv(self.ulazna_datoteka)
        self.podaci = [
            TackaPodataka(red.vremenska_oznaka, red.vrijednost, red.kategorija)
            for red in df.itertuples()
        ]
    
    def obradi_podatke(self) -> Iterator[TackaPodataka]:
        for tacka in self.podaci:
            # Primijeni transformacije
            obradjena_tacka = self._transformisi_tacku(tacka)
            if obradjena_tacka:
                yield obradjena_tacka
    
    def _transformisi_tacku(self, tacka: TackaPodataka) -> Optional[TackaPodataka]:
        # Primijeni poslovnu logiku
        if tacka.vrijednost < 0:
            return None
        return TackaPodataka(
            vremenska_oznaka=tacka.vremenska_oznaka,
            vrijednost=np.log1p(tacka.vrijednost),
            kategorija=tacka.kategorija.upper()
        )
```

Ovim je završen sveobuhvatni Python tutorial sa naprednim funkcijama, najboljim praksama i praktičnim primjerima.

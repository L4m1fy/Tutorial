# Python Програмирање Туторијал

## Садржај
1. [Увод](#увод)
2. [Основни Концепти](#основни-концепти)
3. [Типови Података](#типови-података)
4. [Контролне Структуре](#контролне-структуре)
5. [Функције](#функције)
6. [Објектно Оријентисано Програмирање](#објектно-оријентисано-програмирање)
7. [Модули и Пакети](#модули-и-пакети)
8. [Рад са Датотекама](#рад-са-датотекама)
9. [Руковање Грешкама](#руковање-грешкама)
10. [Напредне Теме](#напредне-теме)
11. [Напредне Python Функције](#напредне-python-функције)
12. [Напредне Технике Тестирања](#напредне-технике-тестирања)
13. [Оптимизација Перформанси](#оптимизација-перформанси)
14. [Најбоље Праксе и Дизајн Обрасци](#најбоље-праксе-и-дизајн-обрасци)
15. [Пример Пројеката](#пример-пројеката)

## Увод
Python је програмски језик високог нивоа познат по својој једноставности и читљивости. Овај туторијал ће вас водити кроз све основне концепте Python програмирања.

### Постављање Python-а
1. Преузмите Python са [python.org](https://python.org)
2. Инсталирајте Python са омогућеном PATH опцијом
3. Проверите инсталацију: `python --version`

## Основни Концепти

### Променљиве и Додељивање
```python
име = "John"      # String (текст)
године = 25      # Integer (цео број)
висина = 1.75    # Float (децимални број)
је_студент = True # Boolean (логичка вредност)
```

### Основне Операције
```python
# Аритметичке операције
збир = 10 + 5
разлика = 10 - 5
производ = 10 * 5
количник = 10 / 5
степен = 2 ** 3
остатак = 10 % 3

# Операције са стринговима
име = "John"
презиме = "Doe"
пуно_име = име + " " + презиме
```

## Типови Података

### Бројеви
```python
# Цео број
x = 5
# Децимални број
y = 3.14
# Комплексни број
z = 2 + 3j
```

### Стрингови
```python
# Креирање стринга
текст = "Здраво, Свете!"
више_линија = """Ово је текст
у више линија"""

# Стринг методе
велика_слова = текст.upper()
мала_слова = текст.lower()
дужина = len(текст)
```

### Листе
```python
# Креирање листе
воће = ["јабука", "банана", "поморанџа"]

# Операције са листама
воће.append("грожђе")
воће.remove("банана")
прво_воће = воће[0]
```

### Речници (Dictionaries)
```python
# Креирање речника
особа = {
    "име": "John",
    "године": 25,
    "град": "Београд"
}

# Операције са речницима
особа["email"] = "john@пример.срб"
године = особа.get("године")
```

## Контролне Структуре

### If Изјаве
```python
године = 18

if године >= 18:
    print("Пунолетан")
elif године >= 13:
    print("Тинејџер")
else:
    print("Дете")
```

### Петље
```python
# For петља
for i in range(5):
    print(i)

# While петља
бројач = 0
while бројач < 5:
    print(бројач)
    бројач += 1
```

## Функције

### Основне Функције
```python
def поздрави(име):
    return f"Здраво, {име}!"

# Позив функције
порука = поздрави("John")
```

### Lambda Функције
```python
квадрат = lambda x: x ** 2
резултат = квадрат(5)  # Враћа 25
```

## Објектно Оријентисано Програмирање

### Класе и Објекти
```python
class Особа:
    def __init__(self, име, године):
        self.име = име
        self.године = године
    
    def представи_се(self):
        return f"Ја сам {self.име}, имам {self.године} година"

# Креирање објекта
особа = Особа("John", 25)
представљање = особа.представи_се()
```

### Наслеђивање
```python
class Студент(Особа):
    def __init__(self, име, године, број_индекса):
        super().__init__(име, године)
        self.број_индекса = број_индекса
    
    def учи(self):
        return f"{self.име} учи"
```

## Модули и Пакети

### Коришћење Уграђених Модула
```python
import math
import random

# Математичке операције
корен = math.sqrt(16)
случајан_број = random.randint(1, 10)
```

### Креирање Сопствених Модула
```python
# мој_модул.py
def сопствена_функција():
    return "Поздрав из сопственог модула!"

# main.py
import мој_модул
резултат = мој_модул.сопствена_функција()
```

## Рад са Датотекама

### Читање и Писање Датотека
```python
# Писање у датотеку
with open("пример.txt", "w") as датотека:
    датотека.write("Здраво, Свете!")

# Читање из датотеке
with open("пример.txt", "r") as датотека:
    садржај = датотека.read()
```

## Руковање Грешкама

### Try-Except Блокови
```python
try:
    резултат = 10 / 0
except ZeroDivisionError:
    print("Није могуће делити са нулом!")
except Exception as e:
    print(f"Дошло је до грешке: {e}")
finally:
    print("Ово се увек извршава")
```

## Напредне Теме

### Декоратори
```python
def мој_декоратор(func):
    def wrapper():
        print("Пре функције")
        func()
        print("После функције")
    return wrapper

@мој_декоратор
def реци_здраво():
    print("Здраво!")
```

### Генератори
```python
def генератор_бројева(n):
    for i in range(n):
        yield i

# Коришћење генератора
ген = генератор_бројева(5)
for број in ген:
    print(број)
```

### Управљање Контекстом
```python
class МојКонтекстМенаџер:
    def __enter__(self):
        print("Улазак у контекст")
        return self
    
    def __exit__(self, exc_type, exc_value, traceback):
        print("Излазак из контекста")

# Коришћење контекст менаџера
with МојКонтекстМенаџер():
    print("Унутар контекста")
```

### List Comprehensions
```python
# List comprehension
квадрати = [x**2 for x in range(10)]

# Dictionary comprehension
речник_квадрата = {x: x**2 for x in range(5)}
```

## Најбоље Праксе

1. Пратите PEP 8 стил писања кода
2. Користите смислена имена променљивих
3. Пишите docstrings за функције и класе
4. Држите функције малим и фокусираним
5. Користите type hints за бољу читљивост
6. Правилно рукујте грешкама
7. Пишите unit тестове за свој код

## Додатни Ресурси

1. [Званична Python Документација](https://docs.python.org)
2. [Python Package Index (PyPI)](https://pypi.org)
3. [Python Заједница Србије](https://python.rs)
4. [Python Туторијали на Српском](https://tutorijalirs.com/python)

## Пројекти за Вежбу

1. Направите једноставан калкулатор
2. Изградите апликацију за to-do листу
3. Имплементирајте једноставан web scraper
4. Направите организатор датотека
5. Изградите једноставну игру (нпр. Икс-Окс)

Не заборавите редовно да вежбате и радите на стварним пројектима како бисте побољшали своје Python програмерске вештине!

## Napredne Python Funkcije

### Tipske Anotacije i Statička Provera Tipova
```python
from typing import List, Dict, Optional, Union, Callable

# Funkcija sa tipskim anotacijama
def izracunaj_statistiku(brojevi: List[float]) -> Dict[str, float]:
    return {
        "srednja_vrednost": sum(brojevi) / len(brojevi),
        "maksimum": max(brojevi),
        "minimum": min(brojevi)
    }

# Složene tipske anotacije
KorisnikID = int
KorisnickoIme = str
PodaciKorisnika = Dict[KorisnikID, KorisnickoIme]

def obradi_korisnika(korisnik_id: KorisnikID, ime: Optional[str] = None) -> None:
    pass

# Tipski aliasi i unije
Broj = Union[int, float]
def kvadriraj_broj(n: Broj) -> Broj:
    return n * n
```

### Kontekst Menadžeri
```python
from contextlib import contextmanager
import time

# Prilagođeni kontekst menadžer
class MeracVremena:
    def __enter__(self):
        self.pocetak = time.time()
        return self

    def __exit__(self, *args):
        self.kraj = time.time()
        self.trajanje = self.kraj - self.pocetak

# Kontekst menadžer korišćenjem dekoratora
@contextmanager
def privremena_datoteka(ime_datoteke: str):
    try:
        f = open(ime_datoteke, 'w')
        yield f
    finally:
        f.close()
        import os
        os.remove(ime_datoteke)

# Upotreba
with MeracVremena() as timer:
    time.sleep(1)
print(f"Operacija je trajala {timer.trajanje:.2f} sekundi")
```

### Asinhrono Programiranje
```python
import asyncio
from aiohttp import ClientSession

async def preuzmi_podatke(url: str) -> dict:
    async with ClientSession() as sesija:
        async with sesija.get(url) as odgovor:
            return await odgovor.json()

async def obradi_urlove(urlovi: List[str]) -> List[dict]:
    zadaci = [preuzmi_podatke(url) for url in urlovi]
    return await asyncio.gather(*zadaci)

# Korišćenje event loop-a
async def main():
    urlovi = [
        "https://api.primer.com/podaci1",
        "https://api.primer.com/podaci2"
    ]
    rezultati = await obradi_urlove(urlovi)
    return rezultati

if __name__ == "__main__":
    asyncio.run(main())
```

### Dekoratori i Metaprogramiranje
```python
from functools import wraps
import time
import logging

# Funkcijski dekorator
def dekorator_merenja_vremena(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        pocetak = time.time()
        rezultat = func(*args, **kwargs)
        kraj = time.time()
        print(f"{func.__name__} je trajala {kraj - pocetak:.2f} sekundi")
        return rezultat
    return wrapper

# Klasni dekorator
def singleton(cls):
    instance = {}
    def get_instance(*args, **kwargs):
        if cls not in instance:
            instance[cls] = cls(*args, **kwargs)
        return instance[cls]
    return get_instance

# Dekorator sa parametrima
def ponovi(max_pokusaja: int = 3, pauza: float = 1.0):
    def dekorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            pokusaji = 0
            while pokusaji < max_pokusaja:
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    pokusaji += 1
                    if pokusaji == max_pokusaja:
                        raise e
                    time.sleep(pauza)
        return wrapper
    return dekorator
```

### Napredne Strukture Podataka
```python
from collections import defaultdict, Counter, deque
from typing import TypeVar, Generic

T = TypeVar('T')

# Generički Stek
class Stek(Generic[T]):
    def __init__(self):
        self._elementi: List[T] = []
    
    def dodaj(self, element: T) -> None:
        self._elementi.append(element)
    
    def ukloni(self) -> T:
        return self._elementi.pop()
    
    def pogledaj(self) -> T:
        return self._elementi[-1]
    
    def je_prazan(self) -> bool:
        return len(self._elementi) == 0

# Korišćenje kolekcija
def obradi_log_datoteku(ime_datoteke: str) -> Dict[str, int]:
    # Automatsko brojanje pojavljivanja
    brojac_reci = Counter()
    
    # Podrazumevani rečnik sa listom
    akcije_korisnika = defaultdict(list)
    
    # Dvostrani red
    nedavni_dogadjaji = deque(maxlen=100)
    
    with open(ime_datoteke) as f:
        for linija in f:
            # Obrada log datoteke...
            pass
            
    return dict(brojac_reci)
```

### Moderne Python Funkcije (Python 3.9+)
```python
# Operatori unije rečnika (Python 3.9+)
recnik1 = {"a": 1, "b": 2}
recnik2 = {"c": 3, "d": 4}
kombinovano = recnik1 | recnik2

# Podudaranje obrazaca (Python 3.10+)
def obradi_komandu(komanda):
    match komanda.split():
        case ["izadji"]:
            return "Izlazim..."
        case ["ucitaj", ime_datoteke]:
            return f"Učitavam {ime_datoteke}"
        case ["sacuvaj", ime_datoteke, "kao", format]:
            return f"Čuvam {ime_datoteke} kao {format}"
        case _:
            return "Nepoznata komanda"

# Operator unije tipova (Python 3.10+)
def obradi_id(id: int | str) -> str:
    return str(id)
```

## Najbolje Prakse i Dizajn Obrasci

### Principi Čistog Koda
```python
# Loše
def p(x, l):
    if l == []: return x
    return p(x * l[0], l[1:])

# Dobro
def izracunaj_proizvod(pocetna_vrednost: float, faktori: List[float]) -> float:
    """Izračunava proizvod početne vrednosti i svih faktora u listi."""
    if not faktori:
        return pocetna_vrednost
    return izracunaj_proizvod(pocetna_vrednost * faktori[0], faktori[1:])

# Loše
class Obj:
    def uradi_nesto(self, x):
        if x > 0:
            # Uradi nešto
            pass
        else:
            # Uradi nešto drugo
            pass

# Dobro
class ObradaPodataka:
    def obradi_podatke(self, vrednost: float) -> None:
        """Obrađuje podatke na osnovu njihove vrednosti."""
        if self._je_pozitivno(vrednost):
            self._obradi_pozitivnu_vrednost(vrednost)
        else:
            self._obradi_negativnu_vrednost(vrednost)
    
    def _je_pozitivno(self, vrednost: float) -> bool:
        return vrednost > 0
```

### Dizajn Obrasci
```python
# Singleton Obrazac
class Singleton:
    _instanca = None
    
    def __new__(cls):
        if cls._instanca is None:
            cls._instanca = super().__new__(cls)
        return cls._instanca

# Factory Obrazac
from abc import ABC, abstractmethod

class Zivotinja(ABC):
    @abstractmethod
    def oglasi_se(self) -> str:
        pass

class Pas(Zivotinja):
    def oglasi_se(self) -> str:
        return "Av!"

class Macka(Zivotinja):
    def oglasi_se(self) -> str:
        return "Mjau!"

class ZivotinjaFabrika:
    def kreiraj_zivotinju(self, tip_zivotinje: str) -> Zivotinja:
        if tip_zivotinje.lower() == "pas":
            return Pas()
        elif tip_zivotinje.lower() == "macka":
            return Macka()
        raise ValueError(f"Nepoznat tip životinje: {tip_zivotinje}")

# Observer Obrazac
class Subjekat:
    def __init__(self):
        self._posmatraci = []
        self._stanje = None
    
    def dodaj(self, posmatrac):
        self._posmatraci.append(posmatrac)
    
    def ukloni(self, posmatrac):
        self._posmatraci.remove(posmatrac)
    
    def obavesti(self):
        for posmatrac in self._posmatraci:
            posmatrac.azuriraj(self._stanje)
    
    @property
    def stanje(self):
        return self._stanje
    
    @stanje.setter
    def stanje(self, vrednost):
        self._stanje = vrednost
        self.obavesti()
```

### Rukovanje Greškama i Logovanje
```python
import logging
from typing import Any, Optional
from dataclasses import dataclass

# Podešavanje logovanja
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@dataclass
class RezultatOperacije:
    uspeh: bool
    podaci: Optional[Any] = None
    greska: Optional[str] = None

class PrilagodjenjaGreska(Exception):
    """Osnovna klasa za prilagođene izuzetke"""
    pass

def obradi_podatke(podaci: Dict[str, Any]) -> RezultatOperacije:
    try:
        # Validacija ulaza
        if not isinstance(podaci, dict):
            raise TypeError("Ulaz mora biti rečnik")
        
        # Obrada podataka
        rezultat = izvrsi_slozenu_operaciju(podaci)
        logger.info(f"Uspešno obrađeni podaci: {podaci}")
        
        return RezultatOperacije(uspeh=True, podaci=rezultat)
    
    except TypeError as e:
        logger.error(f"Nevažeći tip ulaza: {str(e)}")
        return RezultatOperacije(uspeh=False, greska=str(e))
    
    except PrilagodjenjaGreska as e:
        logger.error(f"Greška u poslovnoj logici: {str(e)}")
        return RezultatOperacije(uspeh=False, greska=str(e))
    
    except Exception as e:
        logger.exception("Došlo je do neočekivane greške")
        return RezultatOperacije(uspeh=False, greska="Interna greška servera")
```

## Primer Projekata

### Web API sa FastAPI
```python
from fastapi import FastAPI, HTTPException, Depends
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import List

app = FastAPI()

class KreiranjeKorisnika(BaseModel):
    ime: str
    email: str

class Korisnik(KreiranjeKorisnika):
    id: int
    
    class Config:
        orm_mode = True

@app.post("/korisnici/", response_model=Korisnik)
async def kreiraj_korisnika(korisnik: KreiranjeKorisnika, db: Session = Depends(get_db)):
    db_korisnik = KorisnikModel(**korisnik.dict())
    db.add(db_korisnik)
    db.commit()
    db.refresh(db_korisnik)
    return db_korisnik

@app.get("/korisnici/", response_model=List[Korisnik])
async def dohvati_korisnike(preskoci: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    korisnici = db.query(KorisnikModel).offset(preskoci).limit(limit).all()
    return korisnici
```

### Protok Obrade Podataka
```python
from dataclasses import dataclass
from typing import List, Iterator
import pandas as pd
import numpy as np

@dataclass
class TackaPodataka:
    vremenska_oznaka: float
    vrednost: float
    kategorija: str

class ProtokPodataka:
    def __init__(self, ulazna_datoteka: str):
        self.ulazna_datoteka = ulazna_datoteka
        self.podaci: List[TackaPodataka] = []
    
    def ucitaj_podatke(self) -> None:
        df = pd.read_csv(self.ulazna_datoteka)
        self.podaci = [
            TackaPodataka(red.vremenska_oznaka, red.vrednost, red.kategorija)
            for red in df.itertuples()
        ]
    
    def obradi_podatke(self) -> Iterator[TackaPodataka]:
        for tacka in self.podaci:
            # Primeni transformacije
            obradjena_tacka = self._transformisi_tacku(tacka)
            if obradjena_tacka:
                yield obradjena_tacka
    
    def _transformisi_tacku(self, tacka: TackaPodataka) -> Optional[TackaPodataka]:
        # Primeni poslovnu logiku
        if tacka.vrednost < 0:
            return None
        return TackaPodataka(
            vremenska_oznaka=tacka.vremenska_oznaka,
            vrednost=np.log1p(tacka.vrednost),
            kategorija=tacka.kategorija.upper()
        )
```

Ovim je završen sveobuhvatni Python tutorial sa naprednim funkcijama, najboljim praksama i praktičnim primerima.

# Python Programming Tutorial

## Table of Contents
1. [Introduction](#introduction)
2. [Basic Concepts](#basic-concepts)
3. [Data Types](#data-types)
4. [Control Structures](#control-structures)
5. [Functions](#functions)
6. [Object-Oriented Programming](#object-oriented-programming)
7. [Modules and Packages](#modules-and-packages)
8. [File Handling](#file-handling)
9. [Error Handling](#error-handling)
10. [Advanced Topics](#advanced-topics)
11. [Modern Python Features](#modern-python-features)
12. [Best Practices](#best-practices)
13. [Additional Resources](#additional-resources)
14. [Practice Projects](#practice-projects)
15. [Advanced Projects](#advanced-projects)

## Introduction
Python is a high-level, interpreted programming language known for its simplicity and readability. This tutorial will guide you through all essential concepts of Python programming.

### Setting Up Python
1. Download Python from [python.org](https://python.org)
2. Install Python with PATH option enabled
3. Verify installation: `python --version`

## Basic Concepts

### Variables and Assignment
```python
name = "John"      # String
age = 25          # Integer
height = 1.75     # Float
is_student = True # Boolean
```

### Basic Operations
```python
# Arithmetic
sum = 10 + 5
difference = 10 - 5
product = 10 * 5
quotient = 10 / 5
power = 2 ** 3
remainder = 10 % 3

# String operations
first_name = "John"
last_name = "Doe"
full_name = first_name + " " + last_name
```

## Data Types

### Numbers
```python
# Integer
x = 5
# Float
y = 3.14
# Complex
z = 2 + 3j
```

### Strings
```python
# String creation
text = "Hello, World!"
multiline = """This is a
multiline string"""

# String methods
upper_text = text.upper()
lower_text = text.lower()
length = len(text)
```

### Lists
```python
# List creation
fruits = ["apple", "banana", "orange"]

# List operations
fruits.append("grape")
fruits.remove("banana")
first_fruit = fruits[0]
```

### Dictionaries
```python
# Dictionary creation
person = {
    "name": "John",
    "age": 25,
    "city": "New York"
}

# Dictionary operations
person["email"] = "john@example.com"
age = person.get("age")
```

## Control Structures

### If Statements
```python
age = 18

if age >= 18:
    print("Adult")
elif age >= 13:
    print("Teenager")
else:
    print("Child")
```

### Loops
```python
# For loop
for i in range(5):
    print(i)

# While loop
count = 0
while count < 5:
    print(count)
    count += 1
```

## Functions

### Basic Functions
```python
def greet(name):
    return f"Hello, {name}!"

# Function call
message = greet("John")
```

### Lambda Functions
```python
square = lambda x: x ** 2
result = square(5)  # Returns 25
```

## Object-Oriented Programming

### Classes and Objects
```python
class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age
    
    def introduce(self):
        return f"I am {self.name}, {self.age} years old"

# Creating an object
person = Person("John", 25)
introduction = person.introduce()
```

### Inheritance
```python
class Student(Person):
    def __init__(self, name, age, student_id):
        super().__init__(name, age)
        self.student_id = student_id
    
    def study(self):
        return f"{self.name} is studying"
```

## Modules and Packages

### Using Built-in Modules
```python
import math
import random

# Math operations
sqrt_value = math.sqrt(16)
random_number = random.randint(1, 10)
```

### Creating Custom Modules
```python
# mymodule.py
def custom_function():
    return "Hello from custom module!"

# main.py
import mymodule
result = mymodule.custom_function()
```

## File Handling

### Reading and Writing Files
```python
# Writing to a file
with open("example.txt", "w") as file:
    file.write("Hello, World!")

# Reading from a file
with open("example.txt", "r") as file:
    content = file.read()
```

## Error Handling

### Try-Except Blocks
```python
try:
    result = 10 / 0
except ZeroDivisionError:
    print("Cannot divide by zero!")
except Exception as e:
    print(f"An error occurred: {e}")
finally:
    print("This always executes")
```

## Advanced Topics

### Decorators
```python
def my_decorator(func):
    def wrapper():
        print("Before function")
        func()
        print("After function")
    return wrapper

@my_decorator
def say_hello():
    print("Hello!")
```

### Generators
```python
def number_generator(n):
    for i in range(n):
        yield i

# Using generator
gen = number_generator(5)
for num in gen:
    print(num)
```

### Context Managers
```python
class MyContextManager:
    def __enter__(self):
        print("Entering context")
        return self
    
    def __exit__(self, exc_type, exc_value, traceback):
        print("Exiting context")

# Using context manager
with MyContextManager():
    print("Inside context")
```

### List Comprehensions
```python
# List comprehension
squares = [x**2 for x in range(10)]

# Dictionary comprehension
square_dict = {x: x**2 for x in range(5)}
```

## Modern Python Features

### Type Hints and Annotations
```python
from typing import List, Dict, Optional, Union, TypeVar, Generic

T = TypeVar('T')
class Stack(Generic[T]):
    def __init__(self) -> None:
        self.items: List[T] = []
    
    def push(self, item: T) -> None:
        self.items.append(item)
    
    def pop(self) -> Optional[T]:
        return self.items.pop() if self.items else None

# Type aliases
UserID = int
UserData = Dict[str, Union[str, int]]

def get_user(user_id: UserID) -> Optional[UserData]:
    # Implementation
    pass
```

### Async Programming
```python
import asyncio
from aiohttp import ClientSession

async def fetch_data(url: str) -> dict:
    async with ClientSession() as session:
        async with session.get(url) as response:
            return await response.json()

async def process_urls(urls: List[str]) -> List[dict]:
    tasks = [fetch_data(url) for url in urls]
    return await asyncio.gather(*tasks)

# Using async context managers
async def process_file(filename: str):
    async with aiofiles.open(filename, mode='r') as f:
        content = await f.read()
        return content

# Running async code
async def main():
    urls = [
        'https://api.example.com/data1',
        'https://api.example.com/data2'
    ]
    results = await process_urls(urls)
    print(results)

if __name__ == "__main__":
    asyncio.run(main())
```

### Pattern Matching (Python 3.10+)
```python
def analyze_data(data):
    match data:
        case {"type": "user", "name": str(name), "age": int(age)}:
            return f"User {name} is {age} years old"
        
        case {"type": "post", "title": str(title), "content": str(content)}:
            return f"Post titled '{title}' with content"
        
        case [int(x), int(y), *rest] if x > 0 and y > 0:
            return f"Positive coordinates: ({x}, {y})"
        
        case _:
            return "Unknown data format"

# Using pattern matching with classes
class Point:
    def __init__(self, x: int, y: int):
        self.x = x
        self.y = y

def analyze_point(point):
    match point:
        case Point(x=0, y=0):
            return "At origin"
        case Point(x=x, y=y) if x == y:
            return f"On diagonal at {x}"
        case Point():
            return "Somewhere else"
```

### Data Classes
```python
from dataclasses import dataclass, field
from datetime import datetime

@dataclass(frozen=True)
class User:
    id: int
    name: str
    email: str
    created_at: datetime = field(default_factory=datetime.now)
    active: bool = True
    
    def to_dict(self) -> dict:
        return {
            'id': self.id,
            'name': self.name,
            'email': self.email,
            'created_at': self.created_at.isoformat(),
            'active': self.active
        }

# Inheritance with dataclasses
@dataclass
class AdminUser(User):
    permissions: List[str] = field(default_factory=list)
```

### Modern Error Handling
```python
from contextlib import contextmanager
from typing import Generator

class APIError(Exception):
    def __init__(self, message: str, status_code: int):
        self.status_code = status_code
        super().__init__(message)

@contextmanager
def handle_api_errors() -> Generator[None, None, None]:
    try:
        yield
    except APIError as e:
        print(f"API Error {e.status_code}: {str(e)}")
    except Exception as e:
        print(f"Unexpected error: {str(e)}")
        raise

# Using the context manager
with handle_api_errors():
    # API calls here
    pass
```

### Advanced Decorators
```python
import functools
from typing import Callable, TypeVar, ParamSpec

P = ParamSpec('P')
R = TypeVar('R')

def retry(max_attempts: int = 3, delay: float = 1.0):
    def decorator(func: Callable[P, R]) -> Callable[P, R]:
        @functools.wraps(func)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            last_error = None
            for attempt in range(max_attempts):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_error = e
                    if attempt < max_attempts - 1:
                        time.sleep(delay)
            raise last_error
        return wrapper
    return decorator

# Using the decorator
@retry(max_attempts=3, delay=1.0)
def fetch_data(url: str) -> dict:
    # Implementation
    pass
```

### Modern Testing
```python
import pytest
from unittest.mock import Mock, patch
from typing import Generator
import asyncio

# Fixtures
@pytest.fixture
def database_connection() -> Generator:
    print("Setting up database connection")
    yield "Database connection"
    print("Tearing down database connection")

# Parametrized tests
@pytest.mark.parametrize("input,expected", [
    (1, 2),
    (2, 4),
    (3, 6)
])
def test_multiply_by_two(input, expected):
    assert input * 2 == expected

# Async testing
@pytest.mark.asyncio
async def test_async_function():
    async def async_double(x: int) -> int:
        await asyncio.sleep(0.1)
        return x * 2

    result = await async_double(2)
    assert result == 4

# Mocking
def test_api_call():
    with patch('requests.get') as mock_get:
        mock_get.return_value.status_code = 200
        mock_get.return_value.json.return_value = {"data": "test"}
        
        # Your API call here
        response = mock_get("http://api.example.com")
        assert response.status_code == 200
        assert response.json() == {"data": "test"}

# Property-based testing
from hypothesis import given, strategies as st

@given(st.lists(st.integers()))
def test_list_reversal(lst):
    # This test will be run against many randomly generated lists
    reversed_twice = lst.reverse()
    reversed_twice.reverse()
    assert lst == reversed_twice
```

### Advanced Web Development
```python
from fastapi import FastAPI, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
import uvicorn

app = FastAPI()

# Dependency Injection
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Pydantic models
from pydantic import BaseModel, Field

class UserBase(BaseModel):
    email: str = Field(..., example="user@example.com")
    username: str = Field(..., min_length=3, max_length=50)

class UserCreate(UserBase):
    password: str = Field(..., min_length=8)

class User(UserBase):
    id: int
    is_active: bool = True

    class Config:
        orm_mode = True

# FastAPI routes with dependency injection
@app.post("/users/", response_model=User)
async def create_user(user: UserCreate, db: Session = Depends(get_db)):
    db_user = get_user_by_email(db, email=user.email)
    if db_user:
        raise HTTPException(
            status_code=400,
            detail="Email already registered"
        )
    return create_user_in_db(db=db, user=user)

# WebSocket support
from fastapi import WebSocket

@app.websocket("/ws/{client_id}")
async def websocket_endpoint(websocket: WebSocket, client_id: int):
    await websocket.accept()
    try:
        while True:
            data = await websocket.receive_text()
            await websocket.send_text(f"Message text was: {data}")
    except WebSocketDisconnect:
        print(f"Client #{client_id} disconnected")

# Background tasks
from fastapi import BackgroundTasks

def write_notification(email: str, message: str):
    with open("log.txt", mode="a") as email_file:
        content = f"notification for {email}: {message}\n"
        email_file.write(content)

@app.post("/send-notification/{email}")
async def send_notification(
    email: str,
    background_tasks: BackgroundTasks
):
    background_tasks.add_task(write_notification, email, message="some notification")
    return {"message": "Notification sent in the background"}
```

### Machine Learning Integration
```python
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report
import joblib

class MLModel:
    def __init__(self):
        self.model = RandomForestClassifier()
        self.scaler = StandardScaler()

    def preprocess_data(self, X: np.ndarray) -> np.ndarray:
        return self.scaler.fit_transform(X)

    def train(self, X: np.ndarray, y: np.ndarray) -> None:
        X_scaled = self.preprocess_data(X)
        X_train, X_test, y_train, y_test = train_test_split(
            X_scaled, y, test_size=0.2, random_state=42
        )
        self.model.fit(X_train, y_train)
        y_pred = self.model.predict(X_test)
        print(classification_report(y_test, y_pred))

    def predict(self, X: np.ndarray) -> np.ndarray:
        X_scaled = self.scaler.transform(X)
        return self.model.predict(X_scaled)

    def save_model(self, path: str) -> None:
        joblib.dump((self.model, self.scaler), path)

    @classmethod
    def load_model(cls, path: str) -> 'MLModel':
        instance = cls()
        instance.model, instance.scaler = joblib.load(path)
        return instance

# Using the ML model
def train_and_save_model():
    # Generate sample data
    X = np.random.randn(100, 4)
    y = (X.sum(axis=1) > 0).astype(int)

    model = MLModel()
    model.train(X, y)
    model.save_model("model.joblib")

    # Load and use the model
    loaded_model = MLModel.load_model("model.joblib")
    predictions = loaded_model.predict(np.random.randn(5, 4))
    print("Predictions:", predictions)
```

## Example Projects

### Building a RESTful API
```python
from fastapi import FastAPI, HTTPException, Depends
from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from pydantic import BaseModel
import uvicorn

# Database setup
SQLALCHEMY_DATABASE_URL = "sqlite:///./test.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# Database model
class DBUser(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True)
    username = Column(String)
    password = Column(String)

Base.metadata.create_all(bind=engine)

# Pydantic models
class UserBase(BaseModel):
    email: str
    username: str

class UserCreate(UserBase):
    password: str

class User(UserBase):
    id: int

    class Config:
        orm_mode = True

# FastAPI app
app = FastAPI()

# Dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.post("/users/", response_model=User)
def create_user(user: UserCreate, db: Session = Depends(get_db)):
    db_user = db.query(DBUser).filter(DBUser.email == user.email).first()
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    db_user = DBUser(**user.dict())
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

@app.get("/users/", response_model=list[User])
def read_users(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    users = db.query(DBUser).offset(skip).limit(limit).all()
    return users

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
```

### Building a Real-time Chat Application
```python
import asyncio
import websockets
import json
from dataclasses import dataclass
from typing import Set, Dict

@dataclass
class ChatRoom:
    name: str
    clients: Set[websockets.WebSocketServerProtocol]

class ChatServer:
    def __init__(self):
        self.rooms: Dict[str, ChatRoom] = {}

    async def register(self, websocket: websockets.WebSocketServerProtocol, room_name: str):
        if room_name not in self.rooms:
            self.rooms[room_name] = ChatRoom(room_name, set())
        self.rooms[room_name].clients.add(websocket)

    async def unregister(self, websocket: websockets.WebSocketServerProtocol, room_name: str):
        self.rooms[room_name].clients.remove(websocket)
        if not self.rooms[room_name].clients:
            del self.rooms[room_name]

    async def broadcast(self, room_name: str, message: str):
        if room_name in self.rooms:
            for client in self.rooms[room_name].clients:
                try:
                    await client.send(message)
                except websockets.ConnectionClosed:
                    pass

chat_server = ChatServer()

async def chat(websocket: websockets.WebSocketServerProtocol, path: str):
    try:
        # Receive the initial message with room information
        init_message = await websocket.recv()
        data = json.loads(init_message)
        room_name = data["room"]
        
        await chat_server.register(websocket, room_name)
        try:
            async for message in websocket:
                await chat_server.broadcast(room_name, message)
        finally:
            await chat_server.unregister(websocket, room_name)
    except websockets.ConnectionClosed:
        pass

async def main():
    async with websockets.serve(chat, "localhost", 8765):
        await asyncio.Future()  # run forever

if __name__ == "__main__":
    asyncio.run(main())

# HTML/JavaScript client
"""
<!DOCTYPE html>
<html>
<head>
    <title>WebSocket Chat</title>
</head>
<body>
    <div id="messages"></div>
    <input type="text" id="messageInput" placeholder="Type a message...">
    <button onclick="sendMessage()">Send</button>

    <script>
        const ws = new WebSocket('ws://localhost:8765');
        
        // Join a room when connecting
        ws.onopen = () => {
            ws.send(JSON.stringify({
                room: 'general'
            }));
        };
        
        ws.onmessage = (event) => {
            const messages = document.getElementById('messages');
            messages.innerHTML += `<p>${event.data}</p>`;
        };
        
        function sendMessage() {
            const input = document.getElementById('messageInput');
            ws.send(input.value);
            input.value = '';
        }
    </script>
</body>
</html>
```

### Building a Task Queue System
```python
import redis
import json
import time
from typing import Callable, Any, Dict
from dataclasses import dataclass
import threading
import uuid

@dataclass
class Task:
    id: str
    func: str
    args: tuple
    kwargs: dict
    status: str
    result: Any = None

class TaskQueue:
    def __init__(self, redis_url: str = "redis://localhost:6379"):
        self.redis = redis.from_url(redis_url)
        self.tasks: Dict[str, Task] = {}
        self.functions: Dict[str, Callable] = {}

    def register_function(self, func: Callable):
        self.functions[func.__name__] = func
        return func

    def enqueue(self, func: Callable, *args, **kwargs) -> str:
        task_id = str(uuid.uuid4())
        task = Task(
            id=task_id,
            func=func.__name__,
            args=args,
            kwargs=kwargs,
            status="pending"
        )
        self.tasks[task_id] = task
        self.redis.lpush(
            "task_queue",
            json.dumps({
                "id": task_id,
                "func": func.__name__,
                "args": args,
                "kwargs": kwargs
            })
        )
        return task_id

    def get_task_status(self, task_id: str) -> Dict[str, Any]:
        task = self.tasks.get(task_id)
        if task:
            return {
                "id": task.id,
                "status": task.status,
                "result": task.result
            }
        return {"error": "Task not found"}

    def process_tasks(self):
        while True:
            # Get task from Redis queue
            task_data = self.redis.brpop("task_queue")
            if task_data:
                task_info = json.loads(task_data[1])
                task_id = task_info["id"]
                task = self.tasks[task_id]
                
                try:
                    # Execute the task
                    func = self.functions[task.func]
                    result = func(*task.args, **task.kwargs)
                    
                    # Update task status and result
                    task.status = "completed"
                    task.result = result
                except Exception as e:
                    task.status = "failed"
                    task.result = str(e)

    def start_worker(self, num_threads: int = 1):
        for _ in range(num_threads):
            thread = threading.Thread(target=self.process_tasks)
            thread.daemon = True
            thread.start()

# Example usage
queue = TaskQueue()

@queue.register_function
def add(x: int, y: int) -> int:
    time.sleep(1)  # Simulate long-running task
    return x + y

@queue.register_function
def multiply(x: int, y: int) -> int:
    time.sleep(1)  # Simulate long-running task
    return x * y

# Start worker threads
queue.start_worker(num_threads=2)

# Enqueue tasks
task1_id = queue.enqueue(add, 2, 3)
task2_id = queue.enqueue(multiply, 4, 5)

# Check task status
print(queue.get_task_status(task1_id))
print(queue.get_task_status(task2_id))

# Wait for tasks to complete
time.sleep(2)

print(queue.get_task_status(task1_id))
print(queue.get_task_status(task2_id))
```

## Best Practices

1. Follow PEP 8 style guide
2. Use meaningful variable names
3. Write docstrings for functions and classes
4. Keep functions small and focused
5. Use type hints for better code readability
6. Handle errors appropriately
7. Write unit tests for your code

## Additional Resources

1. [Official Python Documentation](https://docs.python.org)
2. [Python Package Index (PyPI)](https://pypi.org)
3. [Real Python Tutorials](https://realpython.com)
4. [Python Weekly Newsletter](https://pythonweekly.com)

## Practice Projects

1. Create a simple calculator
2. Build a to-do list application
3. Implement a basic web scraper
4. Create a file organizer
5. Build a simple game (e.g., Tic-tac-toe)

## Advanced Projects

1. Build a Modern Web API
   - Use FastAPI or Django REST framework
   - Implement async views
   - Add type hints
   - Include comprehensive testing

2. Create a Data Processing Pipeline
   - Use async programming
   - Implement parallel processing
   - Add error handling
   - Include monitoring

3. Develop a CLI Application
   - Use Click or Typer
   - Implement rich terminal output
   - Add progress bars
   - Include configuration management

4. Build a Machine Learning Pipeline
   - Use modern ML libraries
   - Implement data validation
   - Add experiment tracking
   - Include model serving

5. Create a Microservices Application
   - Use modern messaging
   - Implement service discovery
   - Add health checks
   - Include logging and monitoring

Remember to:
- Use type hints consistently
- Write comprehensive tests
- Document your code
- Follow PEP 8 guidelines
- Use modern Python features appropriately

## Advanced Python Features

### Type Hints and Static Type Checking
```python
from typing import List, Dict, Optional, Union, Callable

# Function with type hints
def calculate_statistics(numbers: List[float]) -> Dict[str, float]:
    return {
        "mean": sum(numbers) / len(numbers),
        "max": max(numbers),
        "min": min(numbers)
    }

# Complex type hints
UserID = int
Username = str
UserData = Dict[UserID, Username]

def process_user(user_id: UserID, name: Optional[str] = None) -> None:
    pass

# Type aliases and unions
Number = Union[int, float]
def square_number(n: Number) -> Number:
    return n * n
```

### Context Managers
```python
from contextlib import contextmanager
import time

# Custom context manager
class Timer:
    def __enter__(self):
        self.start = time.time()
        return self

    def __exit__(self, *args):
        self.end = time.time()
        self.duration = self.end - self.start

# Context manager using decorator
@contextmanager
def temporary_file(filename: str):
    try:
        f = open(filename, 'w')
        yield f
    finally:
        f.close()
        import os
        os.remove(filename)

# Usage
with Timer() as timer:
    time.sleep(1)
print(f"Operation took {timer.duration:.2f} seconds")
```

### Asynchronous Programming
```python
import asyncio
from aiohttp import ClientSession

async def fetch_data(url: str) -> dict:
    async with ClientSession() as session:
        async with session.get(url) as response:
            return await response.json()

async def process_urls(urls: List[str]) -> List[dict]:
    tasks = [fetch_data(url) for url in urls]
    return await asyncio.gather(*tasks)

# Event loop usage
async def main():
    urls = [
        "https://api.example.com/data1",
        "https://api.example.com/data2"
    ]
    results = await process_urls(urls)
    return results

if __name__ == "__main__":
    asyncio.run(main())
```

### Decorators and Metaprogramming
```python
from functools import wraps
import time
import logging

# Function decorator
def timer_decorator(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        end = time.time()
        print(f"{func.__name__} took {end - start:.2f} seconds")
        return result
    return wrapper

# Class decorator
def singleton(cls):
    instances = {}
    def get_instance(*args, **kwargs):
        if cls not in instances:
            instances[cls] = cls(*args, **kwargs)
        return instances[cls]
    return get_instance

# Decorator with parameters
def retry(max_attempts: int = 3, delay: float = 1.0):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            attempts = 0
            while attempts < max_attempts:
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    attempts += 1
                    if attempts == max_attempts:
                        raise e
                    time.sleep(delay)
        return wrapper
    return decorator
```

### Advanced Data Structures
```python
from collections import defaultdict, Counter, deque
from typing import TypeVar, Generic

T = TypeVar('T')

# Custom Generic Stack
class Stack(Generic[T]):
    def __init__(self):
        self._items: List[T] = []
    
    def push(self, item: T) -> None:
        self._items.append(item)
    
    def pop(self) -> T:
        return self._items.pop()
    
    def peek(self) -> T:
        return self._items[-1]
    
    def is_empty(self) -> bool:
        return len(self._items) == 0

# Using collections
def process_log_file(filename: str) -> Dict[str, int]:
    # Count occurrences automatically
    word_counts = Counter()
    
    # Default dictionary with list
    user_actions = defaultdict(list)
    
    # Double-ended queue
    recent_events = deque(maxlen=100)
    
    with open(filename) as f:
        for line in f:
            # Process log file...
            pass
            
    return dict(word_counts)
```

### Modern Python Features (Python 3.9+)
```python
# Dictionary union operators (Python 3.9+)
dict1 = {"a": 1, "b": 2}
dict2 = {"c": 3, "d": 4}
combined = dict1 | dict2

# Pattern matching (Python 3.10+)
def process_command(command):
    match command.split():
        case ["quit"]:
            return "Exiting..."
        case ["load", filename]:
            return f"Loading {filename}"
        case ["save", filename, "as", format]:
            return f"Saving {filename} as {format}"
        case _:
            return "Unknown command"

# Type union operator (Python 3.10+)
def process_id(id: int | str) -> str:
    return str(id)

# ParamSpec and Concatenate (Python 3.10+)
from typing import ParamSpec, Concatenate
P = ParamSpec('P')

def add_logging(f: Callable[P, int]) -> Callable[P, int]:
    def wrapped(*args: P.args, **kwargs: P.kwargs) -> int:
        print(f"Calling {f.__name__}")
        return f(*args, **kwargs)
    return wrapped
```

### Advanced Testing Techniques
```python
import pytest
from unittest.mock import Mock, patch
from dataclasses import dataclass

@dataclass
class User:
    id: int
    name: str
    email: str

class UserService:
    def __init__(self, db):
        self.db = db
    
    def get_user(self, user_id: int) -> Optional[User]:
        return self.db.query(User).filter_by(id=user_id).first()

# Fixtures
@pytest.fixture
def mock_db():
    return Mock()

@pytest.fixture
def user_service(mock_db):
    return UserService(mock_db)

# Parametrized tests
@pytest.mark.parametrize("user_id,expected_name", [
    (1, "John"),
    (2, "Jane"),
    (3, None)
])
def test_get_user(user_service, mock_db, user_id, expected_name):
    # Arrange
    mock_db.query.return_value.filter_by.return_value.first.return_value = (
        User(id=user_id, name=expected_name, email="test@example.com")
        if expected_name else None
    )
    
    # Act
    result = user_service.get_user(user_id)
    
    # Assert
    if expected_name:
        assert result.name == expected_name
    else:
        assert result is None
```

### Performance Optimization
```python
from functools import lru_cache
import cProfile
import pstats
import io

# Memoization with LRU Cache
@lru_cache(maxsize=128)
def fibonacci(n: int) -> int:
    if n < 2:
        return n
    return fibonacci(n-1) + fibonacci(n-2)

# Profiling decorator
def profile(func):
    def wrapper(*args, **kwargs):
        pr = cProfile.Profile()
        pr.enable()
        result = func(*args, **kwargs)
        pr.disable()
        s = io.StringIO()
        ps = pstats.Stats(pr, stream=s).sort_stats('cumulative')
        ps.print_stats()
        print(s.getvalue())
        return result
    return wrapper

# Generator for memory efficiency
def process_large_file(filename: str):
    with open(filename) as f:
        for line in f:
            # Process line by line instead of loading entire file
            yield line.strip().split(',')
```

## Best Practices and Design Patterns

### Clean Code Principles
```python
# Bad
def p(x, l):
    if l == []: return x
    return p(x * l[0], l[1:])

# Good
def calculate_product(initial_value: float, factors: List[float]) -> float:
    """Calculate the product of initial_value and all factors in the list."""
    if not factors:
        return initial_value
    return calculate_product(initial_value * factors[0], factors[1:])

# Bad
class Obj:
    def do_something(self, x):
        if x > 0:
            # Do something
            pass
        else:
            # Do something else
            pass

# Good
class DataProcessor:
    def process_data(self, value: float) -> None:
        """Process data based on its value."""
        if self._is_positive(value):
            self._handle_positive_value(value)
        else:
            self._handle_negative_value(value)
    
    def _is_positive(self, value: float) -> bool:
        return value > 0
```

### Design Patterns
```python
# Singleton Pattern
class Singleton:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

# Factory Pattern
from abc import ABC, abstractmethod

class Animal(ABC):
    @abstractmethod
    def speak(self) -> str:
        pass

class Dog(Animal):
    def speak(self) -> str:
        return "Woof!"

class Cat(Animal):
    def speak(self) -> str:
        return "Meow!"

class AnimalFactory:
    def create_animal(self, animal_type: str) -> Animal:
        if animal_type.lower() == "dog":
            return Dog()
        elif animal_type.lower() == "cat":
            return Cat()
        raise ValueError(f"Unknown animal type: {animal_type}")

# Observer Pattern
class Subject:
    def __init__(self):
        self._observers = []
        self._state = None
    
    def attach(self, observer):
        self._observers.append(observer)
    
    def detach(self, observer):
        self._observers.remove(observer)
    
    def notify(self):
        for observer in self._observers:
            observer.update(self._state)
    
    @property
    def state(self):
        return self._state
    
    @state.setter
    def state(self, value):
        self._state = value
        self.notify()
```

### Error Handling and Logging
```python
import logging
from typing import Any, Optional
from dataclasses import dataclass

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@dataclass
class OperationResult:
    success: bool
    data: Optional[Any] = None
    error: Optional[str] = None

class CustomError(Exception):
    """Base class for custom exceptions"""
    pass

def process_data(data: Dict[str, Any]) -> OperationResult:
    try:
        # Validate input
        if not isinstance(data, dict):
            raise TypeError("Input must be a dictionary")
        
        # Process data
        result = perform_complex_operation(data)
        logger.info(f"Successfully processed data: {data}")
        
        return OperationResult(success=True, data=result)
    
    except TypeError as e:
        logger.error(f"Invalid input type: {str(e)}")
        return OperationResult(success=False, error=str(e))
    
    except CustomError as e:
        logger.error(f"Business logic error: {str(e)}")
        return OperationResult(success=False, error=str(e))
    
    except Exception as e:
        logger.exception("Unexpected error occurred")
        return OperationResult(success=False, error="Internal server error")
```

## Example Projects

### Web API with FastAPI
```python
from fastapi import FastAPI, HTTPException, Depends
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import List

app = FastAPI()

class UserCreate(BaseModel):
    name: str
    email: str

class User(UserCreate):
    id: int
    
    class Config:
        orm_mode = True

@app.post("/users/", response_model=User)
async def create_user(user: UserCreate, db: Session = Depends(get_db)):
    db_user = UserModel(**user.dict())
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

@app.get("/users/", response_model=List[User])
async def get_users(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    users = db.query(UserModel).offset(skip).limit(limit).all()
    return users
```

### Data Processing Pipeline
```python
from dataclasses import dataclass
from typing import List, Iterator
import pandas as pd
import numpy as np

@dataclass
class DataPoint:
    timestamp: float
    value: float
    category: str

class DataPipeline:
    def __init__(self, input_file: str):
        self.input_file = input_file
        self.data: List[DataPoint] = []
    
    def load_data(self) -> None:
        df = pd.read_csv(self.input_file)
        self.data = [
            DataPoint(row.timestamp, row.value, row.category)
            for row in df.itertuples()
        ]
    
    def process_data(self) -> Iterator[DataPoint]:
        for point in self.data:
            # Apply transformations
            processed_point = self._transform_point(point)
            if processed_point:
                yield processed_point
    
    def _transform_point(self, point: DataPoint) -> Optional[DataPoint]:
        # Apply business logic
        if point.value < 0:
            return None
        return DataPoint(
            timestamp=point.timestamp,
            value=np.log1p(point.value),
            category=point.category.upper()
        )
```

This concludes the comprehensive Python tutorial with advanced features, best practices, and practical examples.

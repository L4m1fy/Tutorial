# C# Programming Tutorial

## Table of Contents
1. [Introduction](#introduction)
2. [Basic Concepts](#basic-concepts)
3. [Object-Oriented Programming](#object-oriented-programming)
4. [Advanced Features](#advanced-features)
5. [Modern C# Features](#modern-c-features)
6. [Design Patterns](#design-patterns)
7. [Best Practices](#best-practices)
8. [Example Projects](#example-projects)

## Introduction

C# is a modern, object-oriented programming language developed by Microsoft. This tutorial covers essential concepts and advanced features of C#.

### Getting Started
```csharp
// Basic Hello World Program
using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Hello, World!");
    }
}
```

## Basic Concepts

### Variables and Data Types
```csharp
// Value Types
int number = 42;
double pi = 3.14159;
bool isValid = true;
char letter = 'A';

// Reference Types
string text = "Hello, C#!";
object obj = new object();

// Nullable Types
int? nullableNumber = null;
```

### Control Structures
```csharp
// If-else statement
if (number > 0)
{
    Console.WriteLine("Positive");
}
else if (number < 0)
{
    Console.WriteLine("Negative");
}
else
{
    Console.WriteLine("Zero");
}

// Switch expression (C# 8.0+)
string result = number switch
{
    > 0 => "Positive",
    < 0 => "Negative",
    _ => "Zero"
};

// Loops
for (int i = 0; i < 5; i++)
{
    Console.WriteLine($"Iteration {i}");
}

foreach (var item in collection)
{
    Console.WriteLine(item);
}

while (condition)
{
    // Code
}

do
{
    // Code
} while (condition);
```

## Object-Oriented Programming

### Classes and Objects
```csharp
public class Person
{
    // Properties
    public string Name { get; set; }
    public int Age { get; set; }
    
    // Constructor
    public Person(string name, int age)
    {
        Name = name;
        Age = age;
    }
    
    // Method
    public void Introduce()
    {
        Console.WriteLine($"Hi, I'm {Name} and I'm {Age} years old.");
    }
}

// Using the class
var person = new Person("John", 30);
person.Introduce();
```

### Inheritance and Polymorphism
```csharp
public abstract class Shape
{
    public abstract double CalculateArea();
}

public class Circle : Shape
{
    public double Radius { get; set; }
    
    public Circle(double radius)
    {
        Radius = radius;
    }
    
    public override double CalculateArea()
    {
        return Math.PI * Radius * Radius;
    }
}

public class Rectangle : Shape
{
    public double Width { get; set; }
    public double Height { get; set; }
    
    public Rectangle(double width, double height)
    {
        Width = width;
        Height = height;
    }
    
    public override double CalculateArea()
    {
        return Width * Height;
    }
}
```

## Advanced Features

### LINQ (Language Integrated Query)
```csharp
var numbers = Enumerable.Range(1, 10);

// Query syntax
var evenNumbers = from n in numbers
                 where n % 2 == 0
                 select n;

// Method syntax
var oddNumbers = numbers.Where(n => n % 2 != 0);

// Complex LINQ operations
var result = numbers
    .Where(n => n > 5)
    .Select(n => new { Number = n, Square = n * n })
    .OrderByDescending(x => x.Square)
    .Take(3);
```

### Async/Await
```csharp
public class DataService
{
    public async Task<string> FetchDataAsync()
    {
        using var client = new HttpClient();
        var response = await client.GetStringAsync("https://api.example.com/data");
        return response;
    }
}

public class Program
{
    public static async Task Main()
    {
        var service = new DataService();
        try
        {
            var data = await service.FetchDataAsync();
            Console.WriteLine(data);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error: {ex.Message}");
        }
    }
}
```

### Generic Types
```csharp
public class GenericRepository<T> where T : class
{
    private readonly List<T> _items = new();
    
    public void Add(T item)
    {
        _items.Add(item);
    }
    
    public IEnumerable<T> GetAll()
    {
        return _items.AsReadOnly();
    }
    
    public T GetById(Func<T, bool> predicate)
    {
        return _items.FirstOrDefault(predicate);
    }
}

// Using the generic repository
var peopleRepo = new GenericRepository<Person>();
peopleRepo.Add(new Person("Alice", 25));
```

## Modern C# Features

### Records (C# 9.0+)
```csharp
public record PersonRecord(string Name, int Age);

// Using records
var person1 = new PersonRecord("John", 30);
var person2 = person1 with { Age = 31 };

// Record with additional members
public record Employee(string Name, int Age, string Department)
{
    public decimal CalculateSalary() => 50000m;
}
```

### Pattern Matching
```csharp
public static string DescribeValue(object obj) =>
    obj switch
    {
        string s => $"String of length {s.Length}",
        int n when n < 0 => "Negative number",
        int n => $"Positive number: {n}",
        Person { Age: > 18 } p => $"Adult: {p.Name}",
        null => "Null value",
        _ => "Unknown type"
    };
```

### Top-level Statements (C# 9.0+)
```csharp
// Program.cs
using System;

Console.WriteLine("Hello, World!");
await DoSomethingAsync();

async Task DoSomethingAsync()
{
    await Task.Delay(1000);
    Console.WriteLine("Done!");
}
```

### Init-only Properties (C# 9.0+)
```csharp
public class Configuration
{
    public string Host { get; init; }
    public int Port { get; init; }
    public string Database { get; init; }
}

var config = new Configuration
{
    Host = "localhost",
    Port = 5432,
    Database = "mydb"
};
```

## Design Patterns

### Singleton Pattern
```csharp
public sealed class Singleton
{
    private static readonly Lazy<Singleton> _instance =
        new Lazy<Singleton>(() => new Singleton());
        
    public static Singleton Instance => _instance.Value;
    
    private Singleton() { }
    
    public void DoSomething()
    {
        Console.WriteLine("Singleton method called");
    }
}
```

### Factory Pattern
```csharp
public interface IAnimal
{
    void MakeSound();
}

public class Dog : IAnimal
{
    public void MakeSound() => Console.WriteLine("Woof!");
}

public class Cat : IAnimal
{
    public void MakeSound() => Console.WriteLine("Meow!");
}

public static class AnimalFactory
{
    public static IAnimal CreateAnimal(string type) =>
        type.ToLower() switch
        {
            "dog" => new Dog(),
            "cat" => new Cat(),
            _ => throw new ArgumentException("Invalid animal type")
        };
}
```

## Example Projects

### Building a REST API
```csharp
[ApiController]
[Route("api/[controller]")]
public class UsersController : ControllerBase
{
    private readonly IUserService _userService;
    
    public UsersController(IUserService userService)
    {
        _userService = userService;
    }
    
    [HttpGet]
    public async Task<ActionResult<IEnumerable<User>>> GetUsers()
    {
        var users = await _userService.GetAllUsersAsync();
        return Ok(users);
    }
    
    [HttpPost]
    public async Task<ActionResult<User>> CreateUser(CreateUserDto dto)
    {
        var user = await _userService.CreateUserAsync(dto);
        return CreatedAtAction(nameof(GetUsers), new { id = user.Id }, user);
    }
}
```

### Building a Desktop Application
```csharp
public partial class MainWindow : Window
{
    private readonly ObservableCollection<TodoItem> _todos = new();
    
    public MainWindow()
    {
        InitializeComponent();
        TodoList.ItemsSource = _todos;
    }
    
    private void AddTodo_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(TodoInput.Text))
            return;
            
        _todos.Add(new TodoItem
        {
            Title = TodoInput.Text,
            CreatedAt = DateTime.Now
        });
        
        TodoInput.Clear();
    }
}

public class TodoItem
{
    public string Title { get; set; }
    public DateTime CreatedAt { get; set; }
    public bool IsCompleted { get; set; }
}
```

## Best Practices

1. Use meaningful names for variables, methods, and classes
2. Follow C# naming conventions
3. Write clean, maintainable code
4. Use proper exception handling
5. Implement interfaces for better abstraction
6. Use dependency injection
7. Write unit tests
8. Document your code
9. Use async/await properly
10. Follow SOLID principles

## Additional Resources

1. [Microsoft C# Documentation](https://docs.microsoft.com/en-us/dotnet/csharp/)
2. [C# Programming Guide](https://docs.microsoft.com/en-us/dotnet/csharp/programming-guide/)
3. [.NET API Browser](https://docs.microsoft.com/en-us/dotnet/api/)
4. [C# Corner](https://www.c-sharpcorner.com/)

## Advanced Topics

### Asynchronous Programming
```csharp
// Basic async/await pattern
public async Task<string> DownloadDataAsync()
{
    using var client = new HttpClient(); // Create HTTP client for web requests
    return await client.GetStringAsync("https://api.example.com/data"); // Asynchronously fetch data
}

// Multiple async operations
public async Task ProcessDataAsync()
{
    var task1 = DownloadDataAsync(); // Start first download
    var task2 = DownloadDataAsync(); // Start second download in parallel
    
    await Task.WhenAll(task1, task2); // Wait for both downloads to complete
}
```

### Collections and Data Structures
```csharp
// List<T> - Dynamic array implementation
List<int> numbers = new(); // Modern C# list initialization
numbers.Add(1); // Add single element
numbers.AddRange(new[] { 2, 3, 4 }); // Add multiple elements

// Dictionary<TKey, TValue> - Key-value pairs
Dictionary<string, int> ages = new()
{
    ["John"] = 25, // Initialize with values
    ["Alice"] = 30
};

// HashSet<T> - Unique elements collection
HashSet<string> uniqueNames = new()
{
    "John", // Duplicates are automatically removed
    "Alice",
    "John" // This won't be added
};

// Queue<T> - FIFO data structure
Queue<string> printQueue = new();
printQueue.Enqueue("Document1.pdf"); // Add to queue
var nextToPrint = printQueue.Dequeue(); // Remove and return first item

// Stack<T> - LIFO data structure
Stack<string> undoStack = new();
undoStack.Push("Action1"); // Add to top
var lastAction = undoStack.Pop(); // Remove and return top item
```

### Extension Methods
```csharp
public static class StringExtensions
{
    // Extension method for string type
    public static int WordCount(this string str)
    {
        return str.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).Length;
    }
    
    // Extension method with parameters
    public static string Truncate(this string str, int maxLength)
    {
        return str.Length <= maxLength ? str : str[..maxLength] + "...";
    }
}

// Usage of extension methods
string text = "This is a sample text";
int wordCount = text.WordCount(); // Using the extension method
string truncated = text.Truncate(10); // Using parameterized extension method
```

### Delegates and Events
```csharp
// Delegate declaration
public delegate void MessageHandler(string message);

// Event publisher class
public class MessagePublisher
{
    // Event declaration
    public event MessageHandler MessageReceived;
    
    // Method to raise the event
    public void SendMessage(string message)
    {
        MessageReceived?.Invoke(message); // Null-safe event invocation
    }
}

// Event subscriber class
public class MessageSubscriber
{
    public void OnMessageReceived(string message)
    {
        Console.WriteLine($"Message received: {message}");
    }
}

// Usage
var publisher = new MessagePublisher();
var subscriber = new MessageSubscriber();
publisher.MessageReceived += subscriber.OnMessageReceived; // Subscribe to event
```

### Advanced LINQ Operations
```csharp
// Complex data transformations
var products = new List<Product>();

var analysis = products
    .GroupBy(p => p.Category) // Group by category
    .Select(g => new
    {
        Category = g.Key,
        AveragePrice = g.Average(p => p.Price),
        TotalProducts = g.Count(),
        MostExpensive = g.OrderByDescending(p => p.Price).First()
    })
    .OrderByDescending(x => x.TotalProducts);

// Custom LINQ operators
public static class LinqExtensions
{
    public static IEnumerable<T> DistinctBy<T, TKey>(
        this IEnumerable<T> source,
        Func<T, TKey> keySelector)
    {
        HashSet<TKey> seenKeys = new();
        foreach (var element in source)
        {
            if (seenKeys.Add(keySelector(element)))
            {
                yield return element;
            }
        }
    }
}
```

### Memory Management and Disposal Patterns
```csharp
public class ResourceManager : IDisposable
{
    private bool disposed = false;
    private IntPtr nativeResource;
    private ManagedResource managedResource;

    public ResourceManager()
    {
        nativeResource = AllocateNativeResource();
        managedResource = new ManagedResource();
    }

    // Implement IDisposable
    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }

    // Protected disposal method
    protected virtual void Dispose(bool disposing)
    {
        if (!disposed)
        {
            if (disposing)
            {
                // Dispose managed resources
                managedResource?.Dispose();
            }

            // Free unmanaged resources
            if (nativeResource != IntPtr.Zero)
            {
                FreeNativeResource(nativeResource);
                nativeResource = IntPtr.Zero;
            }

            disposed = true;
        }
    }

    // Finalizer
    ~ResourceManager()
    {
        Dispose(false);
    }
}
```

### Advanced Exception Handling
```csharp
public class CustomException : Exception
{
    public int ErrorCode { get; }

    public CustomException(string message, int errorCode) 
        : base(message)
    {
        ErrorCode = errorCode;
    }
}

public async Task ProcessDataWithRetryAsync()
{
    int retryCount = 3;
    int currentAttempt = 0;

    while (currentAttempt < retryCount)
    {
        try
        {
            await ProcessDataAsync();
            break; // Success, exit loop
        }
        catch (HttpRequestException ex)
        {
            currentAttempt++;
            if (currentAttempt == retryCount)
            {
                throw new CustomException(
                    "Failed after multiple retries", 
                    errorCode: 500);
            }
            await Task.Delay(1000 * currentAttempt); // Exponential backoff
        }
    }
}
```

### Reflection and Attributes
```csharp
// Custom attribute
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
public class AuditAttribute : Attribute
{
    public string Description { get; }
    
    public AuditAttribute(string description)
    {
        Description = description;
    }
}

// Using reflection
public class ReflectionExample
{
    public static void InspectType<T>()
    {
        Type type = typeof(T);
        
        // Get all public properties
        var properties = type.GetProperties()
            .Select(p => new
            {
                Name = p.Name,
                Type = p.PropertyType,
                Attributes = p.GetCustomAttributes()
            });
            
        // Get all methods with specific attribute
        var auditedMethods = type.GetMethods()
            .Where(m => m.GetCustomAttribute<AuditAttribute>() != null)
            .Select(m => new
            {
                Name = m.Name,
                Audit = m.GetCustomAttribute<AuditAttribute>()
            });
    }
}
```

### Modern C# Features (C# 9.0+)
```csharp
// Record types
public record Person(string FirstName, string LastName)
{
    public string FullName => $"{FirstName} {LastName}";
}

// Init-only properties
public class Configuration
{
    public string Host { get; init; }
    public int Port { get; init; }
}

// Pattern matching
public static string GetShapeDescription(Shape shape) => shape switch
{
    Circle { Radius: > 10 } => "Large circle",
    Rectangle { Width: var w, Height: var h } when w == h => "Square",
    Triangle { IsRightAngled: true } => "Right triangle",
    _ => "Unknown shape"
};

// Top-level statements
using System;
Console.WriteLine("Hello, World!"); // No explicit Main method needed
```

### Performance Optimization
```csharp
// Span<T> for efficient memory operations
public static void ProcessLargeArray()
{
    byte[] largeArray = new byte[1000000];
    Span<byte> span = largeArray;
    
    // Efficient slicing without allocation
    Span<byte> slice = span.Slice(0, 1000);
    
    // Direct memory manipulation
    for (int i = 0; i < slice.Length; i++)
    {
        slice[i] = (byte)(i % 256);
    }
}

// Using ValueTask for performance
public async ValueTask<int> GetValueAsync()
{
    if (_cache.TryGetValue("key", out var value))
    {
        return (int)value;
    }
    
    return await ExpensiveOperationAsync();
}
```

### Unit Testing Best Practices
```csharp
[TestClass]
public class CalculatorTests
{
    private Calculator _calculator;
    
    [TestInitialize]
    public void Setup()
    {
        _calculator = new Calculator();
    }
    
    [TestMethod]
    [DataRow(1, 2, 3)]
    [DataRow(-1, 1, 0)]
    [DataRow(0, 0, 0)]
    public void Add_ShouldReturnExpectedResult(
        int a, int b, int expected)
    {
        // Arrange
        // Act
        var result = _calculator.Add(a, b);
        
        // Assert
        Assert.AreEqual(expected, result);
    }
    
    [TestMethod]
    [ExpectedException(typeof(DivideByZeroException))]
    public void Divide_ByZero_ShouldThrowException()
    {
        _calculator.Divide(1, 0);
    }
}
```

### Design Patterns Implementation
```csharp
// Singleton Pattern
public sealed class Singleton
{
    private static readonly Lazy<Singleton> _instance =
        new(() => new Singleton());
        
    public static Singleton Instance => _instance.Value;
    
    private Singleton() { }
}

// Factory Method Pattern
public abstract class DocumentFactory
{
    public abstract IDocument CreateDocument();
}

public class PdfFactory : DocumentFactory
{
    public override IDocument CreateDocument()
    {
        return new PdfDocument();
    }
}

// Observer Pattern
public interface IObserver<T>
{
    void Update(T data);
}

public class Observable<T>
{
    private readonly List<IObserver<T>> _observers = new();
    
    public void Attach(IObserver<T> observer)
    {
        _observers.Add(observer);
    }
    
    public void Notify(T data)
    {
        foreach (var observer in _observers)
        {
            observer.Update(data);
        }
    }
}
```

## Best Practices and Tips

### Code Organization
- Use meaningful names for variables, methods, and classes
- Follow the Single Responsibility Principle
- Keep methods small and focused
- Use proper exception handling
- Implement proper logging
- Write comprehensive unit tests
- Document public APIs

### Performance Considerations
- Use appropriate collection types
- Implement proper disposal patterns
- Consider using value types for small, simple types
- Use async/await for I/O operations
- Implement caching where appropriate
- Profile code to identify bottlenecks

### Security Best Practices
- Input validation
- Proper exception handling
- Secure storage of sensitive data
- Use of encryption where necessary
- Implement proper authentication and authorization
- Regular security audits

## Example Projects

### Web API Project Structure
```plaintext
MyApi/
├── Controllers/
│   ├── UserController.cs
│   └── ProductController.cs
├── Models/
│   ├── User.cs
│   └── Product.cs
├── Services/
│   ├── IUserService.cs
│   └── UserService.cs
├── Repositories/
│   ├── IRepository.cs
│   └── Repository.cs
└── Program.cs
```

### Console Application Project
```plaintext
ConsoleApp/
├── Models/
├── Services/
├── Utilities/
└── Program.cs
```

This concludes the comprehensive C# tutorial. Each section includes practical examples and explanations to help you understand and implement C# concepts effectively.
